/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class Products extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger
            = java.util.logging.Logger.getLogger(Products.class.getName());

    private boolean showingArchived = false;

    /**
     * Creates new form Products
     */
    public Products() {

        initComponents();

        // Make table non-editable
        jTable1.setDefaultEditor(Object.class, null);

        // Date
        DateTimeFormatter formatter
                = DateTimeFormatter.ofPattern("MMMM dd, yyyy");

        ZonedDateTime philippinesNow
                = ZonedDateTime.now(ZoneId.of("Asia/Manila"));

        lblDate1.setText(
                philippinesNow.format(formatter)
        );

        // Load products from database
        loadProducts();

        // Search while typing
        setupSearch();

        // Status color coding
        setupTableColors();

        // Make table rows interactable
        jTable1.setSelectionMode(
                javax.swing.ListSelectionModel.SINGLE_SELECTION
        );

        // Double-click a product to view it
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {

            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {

                if (evt.getClickCount() == 2) {
                    viewSelectedProduct();
                }
            }
        });
    }

    private void loadProducts() {

        String search = jTextField1.getText().trim();

        String sql;

        if (showingArchived) {

            sql = "SELECT product_id, product_name, price, stock_quantity "
                    + "FROM products "
                    + "WHERE archived = 1 "
                    + "AND product_name LIKE ? "
                    + "ORDER BY product_name ASC";

        } else {

            sql = "SELECT product_id, product_name, price, stock_quantity "
                    + "FROM products "
                    + "WHERE archived = 0 "
                    + "AND product_name LIKE ? "
                    + "ORDER BY product_name ASC";
        }

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, "%" + search + "%");

            try (ResultSet rs = pst.executeQuery()) {

                DefaultTableModel model
                        = (DefaultTableModel) jTable1.getModel();

                model.setRowCount(0);

                while (rs.next()) {

                    int productId = rs.getInt("product_id");
                    String productName = rs.getString("product_name");
                    double price = rs.getDouble("price");
                    int stock = rs.getInt("stock_quantity");

                    String status;

                    if (stock <= 0) {
                        status = "Out Of Stock";
                    } else if (stock <= 10) {
                        status = "Low Stock";
                    } else {
                        status = "Good";
                    }

                    model.addRow(new Object[]{
                        productName,
                        String.format("₱%.2f", price),
                        stock,
                        status,
                        "View",
                        productId
                    });
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading products:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        
        if (jTable1.getColumnCount() > 5) {

            jTable1.getColumnModel()
                    .getColumn(5)
                    .setMinWidth(0);

            jTable1.getColumnModel()
                    .getColumn(5)
                    .setMaxWidth(0);

            jTable1.getColumnModel()
                    .getColumn(5)
                    .setPreferredWidth(0);
        }
    }

    private void setupSearch() {

        jTextField1.getDocument().addDocumentListener(
                new DocumentListener() {

            @Override
            public void insertUpdate(DocumentEvent e) {
                loadProducts();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                loadProducts();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                loadProducts();
            }
        });
    }

    private void setupTableColors() {

        jTable1.getColumnModel()
                .getColumn(3)
                .setCellRenderer(new DefaultTableCellRenderer() {

                    @Override
                    public Component getTableCellRendererComponent(
                            JTable table,
                            Object value,
                            boolean isSelected,
                            boolean hasFocus,
                            int row,
                            int column) {

                        Component c
                                = super.getTableCellRendererComponent(
                                        table,
                                        value,
                                        isSelected,
                                        hasFocus,
                                        row,
                                        column
                                );

                        if (value != null) {

                            String status
                                    = value.toString();

                            if (status.equals("Good")) {

                                c.setForeground(new Color(0, 128, 0));

                            } else if (status.equals("Low Stock")) {

                                c.setForeground(
                                        new Color(255, 140, 0)
                                );

                            } else if (status.equals("Out Of Stock")) {

                                c.setForeground(Color.RED);
                            }
                        }

                        return c;
                    }
                });
    }

    private void viewSelectedProduct() {

        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            return;
        }

        String product
                = jTable1.getValueAt(selectedRow, 0).toString();

        String price
                = jTable1.getValueAt(selectedRow, 1).toString();

        String stock
                = jTable1.getValueAt(selectedRow, 2).toString();

        String status
                = jTable1.getValueAt(selectedRow, 3).toString();

        JOptionPane.showMessageDialog(
                this,
                "Product: " + product
                + "\nPrice: " + price
                + "\nStock: " + stock
                + "\nStatus: " + status,
                "Product Details",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblDate1 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton14 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));

        jButton1.setBackground(new java.awt.Color(0, 153, 204));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Dashboard");
        jButton1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(0, 153, 204));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Inventory");
        jButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(0, 153, 204));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Sales");
        jButton3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton4.setBackground(new java.awt.Color(0, 153, 204));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Customers");
        jButton4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton5.setBackground(new java.awt.Color(0, 153, 204));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Reports");
        jButton5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(51, 102, 255));
        jButton6.setText("Log Out");
        jButton6.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton6.addActionListener(this::jButton6ActionPerformed);

        jButton7.setBackground(new java.awt.Color(0, 153, 204));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Staff Management");
        jButton7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton7.addActionListener(this::jButton7ActionPerformed);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JMB no bg.png"))); // NOI18N

        jButton9.setBackground(new java.awt.Color(0, 153, 204));
        jButton9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Statement of Account");
        jButton9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton9.addActionListener(this::jButton9ActionPerformed);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI Variable", 1, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("PRODUCTS MANAGEMENT");

        jLabel3.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 204));
        jLabel3.setText("Manage your product details. ");

        lblDate1.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        lblDate1.setForeground(new java.awt.Color(0, 102, 204));
        lblDate1.setText("Date");

        jButton8.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(0, 102, 204));
        jButton8.setText("+ Add Stock");
        jButton8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 1, true));
        jButton8.addActionListener(this::jButton8ActionPerformed);

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Product", "Price", "Stock", "Status", "Action", "Product ID"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Double.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton10.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(0, 153, 204));
        jButton10.setText("Delete ");
        jButton10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));
        jButton10.addActionListener(this::jButton10ActionPerformed);

        jButton11.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(0, 153, 204));
        jButton11.setText("Edit");
        jButton11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));
        jButton11.addActionListener(this::jButton11ActionPerformed);

        jLabel7.setBackground(new java.awt.Color(0, 153, 204));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 153, 255));
        jLabel7.setText("Search:");

        jTextField1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        jButton14.setFont(new java.awt.Font("Segoe UI Semibold", 1, 14)); // NOI18N
        jButton14.setForeground(new java.awt.Color(0, 102, 204));
        jButton14.setText("+Add Product");
        jButton14.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 1, true));
        jButton14.addActionListener(this::jButton14ActionPerformed);

        jButton13.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jButton13.setForeground(new java.awt.Color(0, 153, 204));
        jButton13.setText("Archive Products");
        jButton13.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));
        jButton13.addActionListener(this::jButton13ActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDate1)
                        .addGap(129, 129, 129))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(48, 48, 48)
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 990, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 98, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(jLabel3)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(102, 102, 102)
                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(99, 99, 99)
                        .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(301, 301, 301))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lblDate1))
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(48, 48, 48)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(149, 149, 149))
        );

        jButton12.setBackground(new java.awt.Color(0, 153, 204));
        jButton12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("Products");
        jButton12.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton12.addActionListener(this::jButton12ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(29, 29, 29)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(155, Short.MAX_VALUE))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        AdminDashboard AdminDashboard = new AdminDashboard();

        AdminDashboard.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Inventory Inventory = new Inventory();

        Inventory.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        sales sales = new sales();

        sales.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        customers customers = new customers();

        customers.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        reports reports = new reports();

        reports.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        AdminLogin AdminLoginForm = new AdminLogin();

        AdminLoginForm.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        staffmanagement staffmanagement = new staffmanagement();

        staffmanagement.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        AdminSOA AdminSOA = new AdminSOA();

        AdminSOA.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a product first.",
                    "No Product Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int modelRow = jTable1.convertRowIndexToModel(selectedRow);

        String productName
                = jTable1.getModel().getValueAt(modelRow, 0).toString();

        int productId = Integer.parseInt(
                jTable1.getModel().getValueAt(modelRow, 5).toString()
        );

        String input = JOptionPane.showInputDialog(
                this,
                "Enter quantity to add to " + productName + ":",
                "Add Stock",
                JOptionPane.PLAIN_MESSAGE
        );

        if (input == null) {
            return;
        }

        input = input.trim();

        int quantity;

        try {
            quantity = Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid whole number.",
                    "Invalid Quantity",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (quantity <= 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Quantity must be greater than 0.",
                    "Invalid Quantity",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        String sql
                = "UPDATE products "
                + "SET stock_quantity = stock_quantity + ? "
                + "WHERE product_id = ? AND archived = 0";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, quantity);
            pst.setInt(2, productId);

            int updated = pst.executeUpdate();

            if (updated > 0) {
                JOptionPane.showMessageDialog(
                        this,
                        quantity + " stock(s) added to "
                        + productName + " successfully!",
                        "Stock Added",
                        JOptionPane.INFORMATION_MESSAGE
                );

                loadProducts();
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error adding stock:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        Products products = new Products();

        products.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a product first.",
                    "No Product Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int modelRow = jTable1.convertRowIndexToModel(selectedRow);

        int productId = Integer.parseInt(
                jTable1.getModel().getValueAt(modelRow, 5).toString()
        );

        String productName = jTable1.getModel()
                .getValueAt(modelRow, 0).toString();

        // PERMANENT DELETE: ARCHIVED PRODUCTS ONLY
        if (showingArchived) {

            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to PERMANENTLY DELETE \""
                    + productName + "\"?\n\n"
                    + "All related sale-item records will also be deleted.\n"
                    + "This action cannot be undone.",
                    "Confirm Permanent Deletion",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            String deleteItemsSql
                    = "DELETE FROM sale_items WHERE product_id = ?";

            String deleteProductSql
                    = "DELETE FROM products "
                    + "WHERE product_id = ? AND archived = 1";

            try (Connection conn = DBConnection.getConnection()) {

                conn.setAutoCommit(false);

                try {
                    // 1. Delete linked sale-item records first
                    try (PreparedStatement pst
                            = conn.prepareStatement(deleteItemsSql)) {

                        pst.setInt(1, productId);
                        pst.executeUpdate();
                    }

                    // 2. Delete the archived product
                    int deleted;

                    try (PreparedStatement pst
                            = conn.prepareStatement(deleteProductSql)) {

                        pst.setInt(1, productId);
                        deleted = pst.executeUpdate();
                    }

                    if (deleted == 0) {
                        throw new SQLException(
                                "Product not found or is no longer archived."
                        );
                    }

                    // 3. Commit both deletions
                    conn.commit();

                    JOptionPane.showMessageDialog(
                            this,
                            "\"" + productName
                            + "\" has been permanently deleted.",
                            "Product Deleted",
                            JOptionPane.INFORMATION_MESSAGE
                    );

                    loadProducts();

                } catch (SQLException e) {

                    try {
                        conn.rollback();
                    } catch (SQLException rollbackError) {
                        e.addSuppressed(rollbackError);
                    }

                    JOptionPane.showMessageDialog(
                            this,
                            "Permanent deletion failed.\n\n"
                            + "No changes were committed.\n\n"
                            + e.getMessage(),
                            "Database Error",
                            JOptionPane.ERROR_MESSAGE
                    );

                } finally {
                    try {
                        conn.setAutoCommit(true);
                    } catch (SQLException e) {
                        logger.log(
                                java.util.logging.Level.WARNING,
                                "Could not restore auto-commit.",
                                e
                        );
                    }
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(
                        this,
                        "Database connection error:\n" + e.getMessage(),
                        "Database Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }

            return;
        }

        // EDIT: NORMAL PRODUCTS
        String oldName = jTable1.getModel()
                .getValueAt(modelRow, 0).toString();

        String oldPrice = jTable1.getModel()
                .getValueAt(modelRow, 1).toString()
                .replace("₱", "").trim();

        String oldStock = jTable1.getModel()
                .getValueAt(modelRow, 2).toString();

        String newName = JOptionPane.showInputDialog(
                this, "Enter Product Name:", oldName);

        if (newName == null) {
            return;
        }

        newName = newName.trim();

        if (newName.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this, "Product name cannot be empty.");
            return;
        }

        String priceInput = JOptionPane.showInputDialog(
                this, "Enter Price:", oldPrice);

        if (priceInput == null) {
            return;
        }

        double newPrice;

        try {
            newPrice = Double.parseDouble(priceInput.trim());

            if (!Double.isFinite(newPrice) || newPrice < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this, "Please enter a valid, non-negative price.");
            return;
        }

        String stockInput = JOptionPane.showInputDialog(
                this, "Enter Stock Quantity:", oldStock);

        if (stockInput == null) {
            return;
        }

        int newStock;

        try {
            newStock = Integer.parseInt(stockInput.trim());

            if (newStock < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid, non-negative whole number for stock.");
            return;
        }

        String sql = "UPDATE products "
                + "SET product_name = ?, price = ?, stock_quantity = ? "
                + "WHERE product_id = ? AND archived = 0";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, newName);
            pst.setDouble(2, newPrice);
            pst.setInt(3, newStock);
            pst.setInt(4, productId);

            int updated = pst.executeUpdate();

            if (updated > 0) {
                JOptionPane.showMessageDialog(
                        this, "Product updated successfully!");
                loadProducts();
            } else {
                JOptionPane.showMessageDialog(
                        this, "Product was not found or is archived.");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this, "Error updating product: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a product first.",
                    "No Product Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int modelRow = jTable1.convertRowIndexToModel(selectedRow);

        String productName
                = jTable1.getModel().getValueAt(modelRow, 0).toString();

        int productId
                = Integer.parseInt(
                        jTable1.getModel().getValueAt(modelRow, 5).toString()
                );

        // =========================================================
        // UNARCHIVE
        // =========================================================
        if (showingArchived) {

            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Restore \"" + productName + "\" to the Products list?",
                    "Unarchive Product",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            String sql
                    = "UPDATE products "
                    + "SET archived = 0 "
                    + "WHERE product_id = ? AND archived = 1";

            try (
                    Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

                pst.setInt(1, productId);

                int updated = pst.executeUpdate();

                if (updated > 0) {

                    JOptionPane.showMessageDialog(
                            this,
                            "\"" + productName
                            + "\" has been restored successfully!",
                            "Product Restored",
                            JOptionPane.INFORMATION_MESSAGE
                    );

                    loadProducts();
                }

            } catch (SQLException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Cannot restore this product.\n\n"
                        + e.getMessage(),
                        "Database Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }

            return;
        }

        // =========================================================
        // ARCHIVE
        // =========================================================
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Remove \"" + productName + "\" from the product list?\n\n"
                + "The product will be archived and its sales history will be kept.",
                "Archive Product",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql
                = "UPDATE products "
                + "SET archived = 1, stock_quantity = 0 "
                + "WHERE product_id = ? AND archived = 0";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, productId);

            int updated = pst.executeUpdate();

            if (updated > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "\"" + productName
                        + "\" has been archived.",
                        "Product Archived",
                        JOptionPane.INFORMATION_MESSAGE
                );

                loadProducts();
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cannot archive this product.\n\n"
                    + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // Product Name
        String productName = JOptionPane.showInputDialog(
                this,
                "Enter product name:",
                "Add Product",
                JOptionPane.PLAIN_MESSAGE
        );

        if (productName == null) {
            return;
        }

        productName = productName.trim();

        if (productName.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Product name cannot be empty.",
                    "Invalid Product Name",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // =========================================================
// AUTOMATIC PRODUCT CATEGORY
// =========================================================
        String category;
        String lowerName = productName.toLowerCase();

        if (lowerName.contains("gallon")
                || lowerName.contains("jug")
                || lowerName.contains("20l")
                || lowerName.contains("5 gallon")) {

            category = "Water Gallon";

        } else if (lowerName.contains("bottle")
                || lowerName.contains("500ml")
                || lowerName.contains("350ml")
                || lowerName.contains("750ml")
                || lowerName.contains("1l")) {

            category = "Water Bottle";

        } else {

            category = "Other";
        }

        // Price
        String priceInput = JOptionPane.showInputDialog(
                this,
                "Enter product price:",
                "Add Product",
                JOptionPane.PLAIN_MESSAGE
        );

        if (priceInput == null) {
            return;
        }

        priceInput = priceInput.trim();

        double price;

        try {
            price = Double.parseDouble(priceInput);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid price.",
                    "Invalid Price",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (price < 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Price cannot be negative.",
                    "Invalid Price",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // Initial Stock
        String stockInput = JOptionPane.showInputDialog(
                this,
                "Enter initial stock quantity:",
                "Add Product",
                JOptionPane.PLAIN_MESSAGE
        );

        if (stockInput == null) {
            return;
        }

        stockInput = stockInput.trim();

        int stock;

        try {
            stock = Integer.parseInt(stockInput);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid whole number for stock.",
                    "Invalid Stock",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (stock < 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Stock cannot be negative.",
                    "Invalid Stock",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // Check if product already exists
        String checkSql
                = "SELECT COUNT(*) FROM products "
                + "WHERE product_name = ? AND archived = 0";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement checkPst = conn.prepareStatement(checkSql)) {

            checkPst.setString(1, productName);

            try (ResultSet rs = checkPst.executeQuery()) {

                if (rs.next() && rs.getInt(1) > 0) {

                    JOptionPane.showMessageDialog(
                            this,
                            "A product with the name \""
                            + productName
                            + "\" already exists.",
                            "Product Already Exists",
                            JOptionPane.WARNING_MESSAGE
                    );

                    return;
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error checking product:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        // =========================================================
        // INSERT PRODUCT WITH AUTOMATIC CATEGORY
        // =========================================================
        String sql
                = "INSERT INTO products "
                + "(product_name, product_type, price, stock_quantity, archived) "
                + "VALUES (?, ?, ?, ?, 0)";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, productName);
            pst.setString(2, category);
            pst.setDouble(3, price);
            pst.setInt(4, stock);

            int inserted = pst.executeUpdate();

            if (inserted > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Product added successfully!\n\n"
                        + "Product: " + productName
                        + "\nCategory: " + category
                        + "\nPrice: ₱" + String.format("%.2f", price)
                        + "\nStock: " + stock,
                        "Product Added",
                        JOptionPane.INFORMATION_MESSAGE
                );

                // Refresh Products table
                loadProducts();
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error adding product:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        if (!showingArchived) {

            // Show archived products
            showingArchived = true;
            jTable1.clearSelection();

            jButton13.setText("Back to Products");
            jButton11.setText("DELETE"); // Permanent delete
            jButton10.setText("Unarchive"); // Restore archived product
            jButton10.setVisible(true); // Keep unarchive button visible

            jButton11.setEnabled(true);
            jButton8.setEnabled(false);
            jButton14.setEnabled(false);

            jLabel2.setText("ARCHIVED PRODUCTS MANAGEMENT");
            jLabel3.setText("Manage your archived products.");

            loadProducts();

        } else {

            // Return to normal products
            showingArchived = false;
            jTable1.clearSelection();

            jButton13.setText("Archive Products");
            jButton11.setText("Edit");
            jButton10.setText("Delete");
            jButton10.setVisible(true);

            jButton11.setEnabled(true);
            jButton8.setEnabled(true);
            jButton14.setEnabled(true);

            jLabel2.setText("PRODUCTS MANAGEMENT");
            jLabel3.setText("Manage your product details.");

            loadProducts();
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Products().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lblDate1;
    // End of variables declaration//GEN-END:variables
}
