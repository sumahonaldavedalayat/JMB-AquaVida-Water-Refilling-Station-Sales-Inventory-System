/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.time.LocalDate;
import java.awt.print.PrinterException;
import javax.swing.JTable;
import java.time.format.DateTimeFormatter;
import java.sql.Timestamp;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class reports extends javax.swing.JFrame {

    private boolean viewingArchive = false;

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(reports.class.getName());

    public reports() {
        initComponents();

        setLocationRelativeTo(null);

        jTextField1.setText(
                LocalDate.now()
                        .withDayOfMonth(1)
                        .toString()
        );

        jTextField2.setText(
                LocalDate.now().toString()
        );

        jComboBox1.removeAllItems();
        jComboBox1.addItem("All");
        jComboBox1.addItem("Cash on Delivery");
        jComboBox1.addItem("Gcash");

        DefaultTableModel model = new DefaultTableModel(
                new Object[]{
                    "Date",
                    "Customer Name",
                    "Galloons",
                    "Payment Method",
                    "Total Amount",
                    "Balance Due",
                    "Sale ID"
                }, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTable1.setModel(model);

// Hide the Sale ID column from the visible table.
        javax.swing.table.TableColumn saleIdColumn
                = jTable1.getColumnModel().getColumn(6);

        saleIdColumn.setMinWidth(0);
        saleIdColumn.setMaxWidth(0);
        saleIdColumn.setPreferredWidth(0);
        saleIdColumn.setResizable(false);

        jLabel10.setText("₱ 0.00");
        jLabel11.setText("0");
        jLabel12.setText("0.00 gallons");

        jButton1.addActionListener(e -> {
    if (viewingArchive) {
        generateArchivedReport();
    } else {
        generateReport();
    }
});
        
        jButton3.addActionListener(e -> deleteSelectedSale());

        setupDateListeners();

        generateReport();
        
        jButton5.setVisible(false);
jButton5.setEnabled(false);
    }

    private void generateReport() {

        String fromDate = jTextField1.getText().trim();
        String toDate = jTextField2.getText().trim();

        String paymentMethod = jComboBox1.getSelectedItem() == null
                ? "All"
                : jComboBox1.getSelectedItem().toString();

        // Check if Date From is empty.
        if (fromDate.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the Date From.",
                    "Missing Date From",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // Check if Date To is empty.
        if (toDate.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the Date To.",
                    "Missing Date To",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        LocalDate startDate;
        LocalDate endDate;

        // Validate the date format.
        try {
            startDate = LocalDate.parse(fromDate);
            endDate = LocalDate.parse(toDate);

        } catch (java.time.format.DateTimeParseException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter valid dates in yyyy-MM-dd format.\n"
                    + "Example: 2026-10-12",
                    "Invalid Date",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // Date From must not be later than Date To.
        if (startDate.isAfter(endDate)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Date From cannot be later than Date To.\n\n"
                    + "Date From: " + fromDate + "\n"
                    + "Date To: " + toDate,
                    "Invalid Date Range",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        DefaultTableModel model
                = (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        String sql;

        if ("All".equals(paymentMethod)) {

            sql = "SELECT "
                    + "s.sale_id, "
                    + "c.customer_name, "
                    + "s.sale_date, "
                    + "COALESCE(si.total_quantity, 0) AS quantity, "
                    + "s.payment_method, "
                    + "COALESCE(s.total_amount, 0) AS total_amount, "
                    + "COALESCE(s.balance_due, 0) AS balance_due "
                    + "FROM sales s "
                    + "LEFT JOIN customers c "
                    + "ON c.customer_id = s.customer_id "
                    + "LEFT JOIN ( "
                    + "SELECT sale_id, SUM(quantity) AS total_quantity "
                    + "FROM sale_items "
                    + "GROUP BY sale_id "
                    + ") si ON s.sale_id = si.sale_id "
                    + "WHERE s.sale_date >= ? "
                    + "AND s.sale_date < DATE_ADD(?, INTERVAL 1 DAY) "
                    + "AND s.archived = 0 "
                    + "ORDER BY s.sale_date DESC, c.customer_name ASC";

        } else {

            sql = "SELECT "
                    + "s.sale_id, "
                    + "c.customer_name, "
                    + "s.sale_date, "
                    + "COALESCE(si.total_quantity, 0) AS quantity, "
                    + "s.payment_method, "
                    + "s.total_amount, "
                    + "s.balance_due "
                    + "FROM sales s "
                    + "LEFT JOIN customers c "
                    + "ON c.customer_id = s.customer_id "
                    + "LEFT JOIN ( "
                    + "SELECT sale_id, SUM(quantity) AS total_quantity "
                    + "FROM sale_items "
                    + "GROUP BY sale_id "
                    + ") si ON s.sale_id = si.sale_id "
                    + "WHERE s.sale_date >= ? "
                    + "AND s.sale_date < DATE_ADD(?, INTERVAL 1 DAY) "
                    + "AND s.archived = 0 "
                    + "AND s.payment_method = ? "
                    + "ORDER BY s.sale_date DESC, c.customer_name ASC";
        }

        double totalSales = 0;
        double totalGallons = 0;
        int totalTransactions = 0;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, fromDate);
            pst.setString(2, toDate);

            if (!"All".equals(paymentMethod)) {
                pst.setString(3, paymentMethod);
            }

            try (ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {

                    Object saleId = rs.getObject("sale_id");
                    String customerName = rs.getString("customer_name");

if (customerName == null || customerName.trim().isEmpty()) {
    customerName = "Walk-in Customer";
}

                    Timestamp saleDate = rs.getTimestamp("sale_date");

                    String date = saleDate == null
                            ? "-"
                            : saleDate.toLocalDateTime().format(
                                    DateTimeFormatter.ofPattern(
                                            "yyyy-MM-dd hh:mm a"
                                    )
                            );

                    double quantity = rs.getDouble("quantity");

                    if (rs.wasNull()) {
                        quantity = 0;
                    }

                    String formattedQuantity = (quantity == (long) quantity)
                            ? String.valueOf((long) quantity)
                            : String.valueOf(quantity);

                    String payment = rs.getString("payment_method");
                    double amount = rs.getDouble("total_amount");
                    double balanceDue = rs.getDouble("balance_due");

                    model.addRow(new Object[]{
                        date,
                        customerName,
                        formattedQuantity,
                        payment == null ? "-" : payment,
                        String.format("₱ %.2f", amount),
                        String.format("₱ %.2f", balanceDue),
                        saleId
                    });

                    // Count only actual sales.
                    if (saleId != null) {
                        totalSales += amount;
                        totalGallons += quantity;
                        totalTransactions++;
                    }
                }
            }

            jLabel10.setText(String.format("₱ %.2f", totalSales));
            jLabel11.setText(String.valueOf(totalTransactions));
            jLabel12.setText(
                    String.format("%.2f gallons", totalGallons)
            );

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error generating report:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void generateArchivedReport() {

        String fromDate = jTextField1.getText().trim();
        String toDate = jTextField2.getText().trim();

        String paymentMethod = jComboBox1.getSelectedItem() == null
                ? "All"
                : jComboBox1.getSelectedItem().toString();

        // Validate empty dates
        if (fromDate.isEmpty() || toDate.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter both Date From and Date To.",
                    "Missing Date",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        LocalDate startDate;
        LocalDate endDate;

        // Validate date format
        try {
            startDate = LocalDate.parse(fromDate);
            endDate = LocalDate.parse(toDate);
        } catch (java.time.format.DateTimeParseException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter valid dates in yyyy-MM-dd format.\n"
                    + "Example: 2026-10-12",
                    "Invalid Date",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        // Validate date range
        if (startDate.isAfter(endDate)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Date From cannot be later than Date To.",
                    "Invalid Date Range",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        DefaultTableModel model
                = (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        String sql
                = "SELECT s.sale_id, "
                + "c.customer_name, "
                + "s.sale_date, "
                + "COALESCE(si.total_quantity, 0) AS quantity, "
                + "s.payment_method, "
                + "COALESCE(s.total_amount, 0) AS total_amount, "
                + "COALESCE(s.balance_due, 0) AS balance_due "
                + "FROM sales s "
                + "LEFT JOIN customers c "
                + "ON c.customer_id = s.customer_id "
                + "LEFT JOIN ( "
                + "SELECT sale_id, SUM(quantity) AS total_quantity "
                + "FROM sale_items "
                + "GROUP BY sale_id "
                + ") si ON s.sale_id = si.sale_id "
                + "WHERE s.sale_date >= ? "
                + "AND s.sale_date < DATE_ADD(?, INTERVAL 1 DAY) "
                + "AND s.archived = 1 ";

        if (!"All".equals(paymentMethod)) {
            sql += "AND s.payment_method = ? ";
        }

        sql += "ORDER BY s.sale_date DESC, c.customer_name ASC";

        double totalSales = 0;
        double totalGallons = 0;
        int totalTransactions = 0;

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, fromDate);
            pst.setString(2, toDate);

            if (!"All".equals(paymentMethod)) {
                pst.setString(3, paymentMethod);
            }

            try (ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {

                    Object saleId = rs.getObject("sale_id");

                    String customerName = rs.getString("customer_name");

                    if (customerName == null || customerName.trim().isEmpty()) {
                        customerName = "Walk-in Customer";
                    }

                    Timestamp saleDate = rs.getTimestamp("sale_date");

                    String date = saleDate == null
                            ? "-"
                            : saleDate.toLocalDateTime().format(
                                    DateTimeFormatter.ofPattern(
                                            "yyyy-MM-dd hh:mm a"
                                    )
                            );

                    double quantity = rs.getDouble("quantity");

                    String formattedQuantity = (quantity == (long) quantity)
                            ? String.valueOf((long) quantity)
                            : String.valueOf(quantity);
                    String payment = rs.getString("payment_method");
                    double amount = rs.getDouble("total_amount");
                    double balanceDue = rs.getDouble("balance_due");

                    model.addRow(new Object[]{
                        date,
                        customerName,
                        formattedQuantity,
                        payment == null ? "-" : payment,
                        String.format("₱ %.2f", amount),
                        String.format("₱ %.2f", balanceDue),
                        saleId
                    });

                    if (saleId != null) {
                        totalSales += amount;
                        totalGallons += quantity;
                        totalTransactions++;
                    }
                }
            }

            // Update summary cards
            jLabel10.setText(String.format("₱ %.2f", totalSales));
            jLabel11.setText(String.valueOf(totalTransactions));
            jLabel12.setText(
                    String.format("%.2f gallons", totalGallons)
            );

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error generating archived report:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loadArchivedSales() {
        generateArchivedReport();
    }

    private void setupDateListeners() {

        DocumentListener dateListener = new DocumentListener() {

            @Override
            public void insertUpdate(DocumentEvent e) {
                // Do not show validation warnings while typing.
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                // Do not show validation warnings while deleting text.
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // Do not show validation warnings while editing.
            }
        };

        jTextField1.getDocument().addDocumentListener(dateListener);
        jTextField2.getDocument().addDocumentListener(dateListener);
    }

    private void printReport() {

        if (jTable1.getRowCount() == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "There is no report to print.",
                    "Print Report",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        try {

            boolean complete = jTable1.print(
                    JTable.PrintMode.FIT_WIDTH,
                    new java.text.MessageFormat("JMB AquaVida - Sales Report"),
                    new java.text.MessageFormat("Page {0}")
            );

            if (complete) {

                JOptionPane.showMessageDialog(
                        this,
                        "Report printed successfully!",
                        "Print Report",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Printing was cancelled.",
                        "Print Report",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

        } catch (PrinterException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error printing report:\n" + e.getMessage(),
                    "Print Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void permanentlyDeleteSelectedSale() {

        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an archived sale to permanently delete.",
                    "No Sale Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int modelRow = jTable1.convertRowIndexToModel(selectedRow);
        Object idValue = jTable1.getModel().getValueAt(modelRow, 6);

        if (idValue == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "The selected sale has no valid ID.",
                    "Invalid Sale",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int saleId;

        try {
            saleId = Integer.parseInt(idValue.toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid sale ID.",
                    "Invalid Sale",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String customerName = String.valueOf(
                jTable1.getModel().getValueAt(modelRow, 1)
        );

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "PERMANENTLY DELETE this archived sale?\n\n"
                + "Customer: " + customerName + "\n"
                + "Sale ID: " + saleId + "\n\n"
                + "Its associated payment and item records will also be deleted.\n"
                + "This action cannot be undone.",
                "Confirm Permanent Deletion",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {

            conn.setAutoCommit(false);

            try {
                // Verify and lock the archived sale first.
                try (PreparedStatement pst = conn.prepareStatement(
                        "SELECT sale_id FROM sales "
                        + "WHERE sale_id = ? AND archived = 1 "
                        + "FOR UPDATE")) {

                    pst.setInt(1, saleId);

                    try (ResultSet rs = pst.executeQuery()) {
                        if (!rs.next()) {
                            conn.rollback();

                            JOptionPane.showMessageDialog(
                                    this,
                                    "This sale is no longer archived or does not exist.",
                                    "Deletion Failed",
                                    JOptionPane.WARNING_MESSAGE
                            );
                            return;
                        }
                    }
                }

                // Delete related payment records first.
                try (PreparedStatement pst = conn.prepareStatement(
                        "DELETE FROM payments WHERE sale_id = ?")) {
                    pst.setInt(1, saleId);
                    pst.executeUpdate();
                }

                // Delete related sale items.
                try (PreparedStatement pst = conn.prepareStatement(
                        "DELETE FROM sale_items WHERE sale_id = ?")) {
                    pst.setInt(1, saleId);
                    pst.executeUpdate();
                }

                // Delete the archived sale.
                try (PreparedStatement pst = conn.prepareStatement(
                        "DELETE FROM sales "
                        + "WHERE sale_id = ? AND archived = 1")) {

                    pst.setInt(1, saleId);

                    int deleted = pst.executeUpdate();

                    if (deleted != 1) {
                        throw new SQLException(
                                "The archived sale could not be deleted."
                        );
                    }
                }

                conn.commit();

                JOptionPane.showMessageDialog(
                        this,
                        "Archived sale permanently deleted.",
                        "Deletion Successful",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (SQLException e) {
                conn.rollback();
                throw e;

            } finally {
                conn.setAutoCommit(true);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error permanently deleting sale:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        generateArchivedReport();
    }

    private void deleteSelectedSale() {

        if (viewingArchive) {
            permanentlyDeleteSelectedSale();
            return;
        }

        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a sale to archive.",
                    "No Sale Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int modelRow = jTable1.convertRowIndexToModel(selectedRow);

        // Sale ID is column 6 in the table model.
        Object idValue = jTable1.getModel().getValueAt(modelRow, 6);

        if (idValue == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "The selected row has no valid sale ID.",
                    "Archive Sale",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        int saleId;

        try {
            saleId = Integer.parseInt(idValue.toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid sale ID. Please generate the report again.",
                    "Archive Failed",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String customerName = String.valueOf(
                jTable1.getModel().getValueAt(modelRow, 1)
        );

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to archive this sale?\n\n"
                + "Customer: " + customerName + "\n"
                + "Sale ID: " + saleId + "\n\n"
                + "The sale will be hidden from the active report, "
                + "but its database records will be preserved.",
                "Confirm Archive",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql
                = "UPDATE sales SET archived = 1 "
                + "WHERE sale_id = ? AND archived = 0";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, saleId);

            int updated = pst.executeUpdate();

            if (updated > 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "Sale archived successfully.",
                        "Archive Successful",
                        JOptionPane.INFORMATION_MESSAGE
                );

                // Refresh the report after archiving.
                generateReport();

            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "The sale is already archived or no longer exists.",
                        "Archive Failed",
                        JOptionPane.WARNING_MESSAGE
                );
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error archiving sale:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    
private void unarchiveSelectedSale() {

    // Only allow unarchiving from Archived Sales.
    if (!viewingArchive) {
        return;
    }

    int selectedRow = jTable1.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(
                this,
                "Please select an archived sale to unarchive.",
                "No Sale Selected",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    // Convert the selected row to the model row.
    int modelRow = jTable1.convertRowIndexToModel(selectedRow);

    // Sale ID is column 6 in your table model.
    Object idValue = jTable1.getModel().getValueAt(modelRow, 6);

    if (idValue == null) {
        JOptionPane.showMessageDialog(
                this,
                "The selected sale has no valid ID.",
                "Invalid Sale",
                JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    int saleId;

    try {
        saleId = Integer.parseInt(idValue.toString());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(
                this,
                "Invalid sale ID. Please generate the report again.",
                "Invalid Sale",
                JOptionPane.ERROR_MESSAGE
        );
        return;
    }

    String customerName = String.valueOf(
            jTable1.getModel().getValueAt(modelRow, 1)
    );

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to unarchive this sale?\n\n"
            + "Customer: " + customerName + "\n"
            + "Sale ID: " + saleId + "\n\n"
            + "The sale will return to the regular Reports page.",
            "Confirm Unarchive",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    String sql = "UPDATE sales "
            + "SET archived = 0 "
            + "WHERE sale_id = ? AND archived = 1";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setInt(1, saleId);

        int updated = pst.executeUpdate();

        if (updated > 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "Sale unarchived successfully!",
                    "Unarchive Successful",
                    JOptionPane.INFORMATION_MESSAGE
            );

            // Refresh the archived sales list.
            generateArchivedReport();

        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "The sale is no longer archived or does not exist.",
                    "Unarchive Failed",
                    JOptionPane.WARNING_MESSAGE
            );

            generateArchivedReport();
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Error unarchiving sale:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel5 = new javax.swing.JPanel();
        jButton31 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jButton36 = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton38 = new javax.swing.JButton();
        jButton39 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel6 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel5.setBackground(new java.awt.Color(0, 102, 153));

        jButton31.setBackground(new java.awt.Color(0, 153, 204));
        jButton31.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton31.setForeground(new java.awt.Color(255, 255, 255));
        jButton31.setText("Dashboard");
        jButton31.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton31.addActionListener(this::jButton31ActionPerformed);

        jButton32.setBackground(new java.awt.Color(0, 153, 204));
        jButton32.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton32.setForeground(new java.awt.Color(255, 255, 255));
        jButton32.setText("Inventory");
        jButton32.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton32.addActionListener(this::jButton32ActionPerformed);

        jButton33.setBackground(new java.awt.Color(0, 153, 204));
        jButton33.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton33.setForeground(new java.awt.Color(255, 255, 255));
        jButton33.setText("Sales");
        jButton33.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton33.addActionListener(this::jButton33ActionPerformed);

        jButton34.setBackground(new java.awt.Color(0, 153, 204));
        jButton34.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton34.setForeground(new java.awt.Color(255, 255, 255));
        jButton34.setText("Customers");
        jButton34.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton34.addActionListener(this::jButton34ActionPerformed);

        jButton35.setBackground(new java.awt.Color(0, 153, 204));
        jButton35.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton35.setForeground(new java.awt.Color(255, 255, 255));
        jButton35.setText("Reports");
        jButton35.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton35.addActionListener(this::jButton35ActionPerformed);

        jButton36.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton36.setForeground(new java.awt.Color(51, 102, 255));
        jButton36.setText("Log Out");
        jButton36.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton36.addActionListener(this::jButton36ActionPerformed);

        jButton37.setBackground(new java.awt.Color(0, 153, 204));
        jButton37.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton37.setForeground(new java.awt.Color(255, 255, 255));
        jButton37.setText("Staff Management");
        jButton37.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton37.addActionListener(this::jButton37ActionPerformed);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JMB no bg.png"))); // NOI18N

        jButton38.setBackground(new java.awt.Color(0, 153, 204));
        jButton38.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton38.setForeground(new java.awt.Color(255, 255, 255));
        jButton38.setText("Statement of Account");
        jButton38.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton38.addActionListener(this::jButton38ActionPerformed);

        jButton39.setBackground(new java.awt.Color(0, 153, 204));
        jButton39.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton39.setForeground(new java.awt.Color(255, 255, 255));
        jButton39.setText("Products");
        jButton39.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton39.addActionListener(this::jButton39ActionPerformed);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGap(39, 39, 39)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton38, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addComponent(jLabel5))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(30, 30, 30)
                .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton38, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(140, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("REPORTS");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        jLabel2.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("Date From");

        jTextField1.setText("jTextField1");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        jLabel3.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 204));
        jLabel3.setText("Date To");

        jTextField2.setText("jTextField2");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField2)
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        jLabel4.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 204));
        jLabel4.setText("Payment Method");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cash on Delivery", "Gcash", " " }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 153), 3, true));

        jButton1.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 102, 153));
        jButton1.setText("Generate Report");
        jButton1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 2, true));

        jLabel6.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 204));
        jLabel6.setText("Total Sales");

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\images-removebg-preview (1).png")); // NOI18N
        jLabel10.setText("jLabel10");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel6))
                .addContainerGap(134, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 2, true));

        jLabel7.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 204));
        jLabel7.setText("Total Transactions");

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\istockphoto-2210168269-612x612-r (1).png")); // NOI18N
        jLabel11.setText("jLabel11");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addComponent(jLabel7))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel11)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 255), 2, true));

        jLabel8.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 153, 204));
        jLabel8.setText("Total Galloons Sold");

        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\drop1-removebg-preview (1).png")); // NOI18N
        jLabel12.setText("jLabel12");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel12))
                    .addComponent(jLabel8))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        jLabel14.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 102, 204));
        jLabel14.setText("Sales Report");

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Date", "Customer Name", "Galloons", "Payment Method", "Total Amount"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton2.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 102, 204));
        jButton2.setText("Print Report");
        jButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(0, 102, 204));
        jButton3.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Delete");
        jButton3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));

        jLabel9.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 102, 204));
        jLabel9.setText("Manage sales reports and monitor daily transactions. ");

        jButton4.setBackground(new java.awt.Color(0, 102, 204));
        jButton4.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Archive Sales");
        jButton4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton5.setBackground(new java.awt.Color(0, 102, 204));
        jButton5.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Unarchive Sales");
        jButton5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton5.addActionListener(this::jButton5ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(72, 72, 72))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addGap(16, 16, 16)
                                        .addComponent(jLabel1)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(72, 72, 72))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jLabel9)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(9, 9, 9)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(96, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        AdminDashboard AdminDashboard = new AdminDashboard();

        AdminDashboard.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        Inventory Inventory = new Inventory();

        Inventory.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
        sales sales = new sales();

        sales.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        customers customers = new customers();

        customers.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
        AdminLogin AdminLoginForm = new AdminLogin();

        AdminLoginForm.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
        staffmanagement staffmanagement = new staffmanagement();

        staffmanagement.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
        AdminSOA AdminSOA = new AdminSOA();

        AdminSOA.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        reports reports = new reports();

        reports.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton35ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
        Products products = new Products();

        products.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        if (viewingArchive) {
            generateArchivedReport();
        } else {
            generateReport();
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        viewingArchive = !viewingArchive;

    if (viewingArchive) {
        // Display Archived Sales.
        jLabel1.setText("ARCHIVED SALES");
        jLabel14.setText("Archived Sales");

        jButton4.setText("Back to Reports");
        jButton3.setText("Delete");

        // Show Unarchive Sales only in Archived Sales.
        jButton5.setVisible(true);
        jButton5.setEnabled(true);

        loadArchivedSales();

    } else {
        // Return to the regular Reports page.
        jLabel1.setText("REPORTS");
        jLabel14.setText("Sales Report");

        jButton4.setText("Archive Sales");
        jButton3.setText("Archive Sale");

        // Hide Unarchive Sales on the regular Reports page.
        jButton5.setVisible(false);
        jButton5.setEnabled(false);

        generateReport();
    }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        unarchiveSelectedSale();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        printReport();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new reports().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
