/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.SwingUtilities;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class sales extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(sales.class.getName());

    private final java.util.ArrayList<Integer> customerIds = new java.util.ArrayList<>();
    private final java.util.ArrayList<String> customerContacts = new java.util.ArrayList<>();
    private final java.util.ArrayList<String> customerAddresses = new java.util.ArrayList<>();

    public sales() {

        initComponents();

        allowAmountInput(jTextField6);
        allowAmountInput(jTextField7);

        jLabel38.setText("₱0.00");
        jTextField6.setText("");
        jTextField8.setText(LocalDate.now(
                ZoneId.of("Asia/Manila")).toString());

        // Set the initial text of the four labels.jLabel39.setText("0");
        jLabel39.setText("0");
        jLabel8.setText("0");
        jLabel40.setText("₱0.00");
        jLabel9.setText("₱0.00");

        setupSalesTable();
        loadCustomers();

        jComboBox3.addActionListener(e -> loadSelectedCustomer());

        jTextField2.setEditable(false);
        jTextField3.setEditable(false);

        java.time.LocalDate today
                = java.time.LocalDate.now(
                        java.time.ZoneId.of("Asia/Manila"));

        java.time.LocalDate firstDayOfMonth
                = today.withDayOfMonth(1);

        java.time.format.DateTimeFormatter dateFormatter
                = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd");

        // Date From: first day of the current month
        jTextField4.setText(firstDayOfMonth.format(dateFormatter));

        // Date To: today's date
        jTextField5.setText(today.format(dateFormatter));

        jTextField4.setEditable(true);
        jTextField5.setEditable(true);

        jTextField1.setEditable(false);

        jButton2.addActionListener(e -> saveSales());

        jLabel15.setText("0");
        jLabel17.setText("₱0.00");

        // Reset Amount Paid and Balance Due on startup.
        jTextField7.setText("");
        jLabel41.setText("₱0.00");
        jLabel42.setText("₱0.00");
        jLabel37.setText("₱0.00");

        // STEP 1: Update payment panels whenever jTextField7 changes.
        jTextField7.getDocument().addDocumentListener(
                new javax.swing.event.DocumentListener() {

            @Override
            public void insertUpdate(
                    javax.swing.event.DocumentEvent e) {
                updatePaymentSummary();
            }

            @Override
            public void removeUpdate(
                    javax.swing.event.DocumentEvent e) {
                updatePaymentSummary();
            }

            @Override
            public void changedUpdate(
                    javax.swing.event.DocumentEvent e) {
                updatePaymentSummary();
            }
        }
        );

        // Initialize the payment summary.
        updatePaymentSummary();

        SwingUtilities.invokeLater(() -> {
            formatSalesTable();
            jTable1.repaint();
        });

        jComboBox2.addActionListener(e -> updatePaymentPanel());
        updatePaymentPanel();
    }

    private void allowAmountInput(javax.swing.JTextField textField) {
        textField.setDocument(new javax.swing.text.PlainDocument() {
            @Override
            public void insertString(
                    int offset, String str,
                    javax.swing.text.AttributeSet attr)
                    throws javax.swing.text.BadLocationException {

                if (str == null) {
                    return;
                }

                String current = getText(0, getLength());
                String updated = new StringBuilder(current)
                        .insert(offset, str)
                        .toString();

                // Allow digits and only one decimal point.
                if (updated.matches("\\d*(\\.\\d{0,2})?")) {
                    super.insertString(offset, str, attr);
                }
            }
        });
    }

    private void updatePaymentSummary() {

        try {
            String totalText = jLabel17.getText()
                    .replaceAll("[^0-9.\\-]", "");

            double total = totalText.isEmpty()
                    ? 0.0
                    : Double.parseDouble(totalText);

            String paidText = jTextField7.getText().trim()
                    .replaceAll("[^0-9.\\-]", "");

            double paid = paidText.isEmpty()
                    ? 0.0
                    : Double.parseDouble(paidText);

            java.text.NumberFormat currency
                    = java.text.NumberFormat.getCurrencyInstance(
                            new java.util.Locale("en", "PH"));

            if (paid < 0) {
                paid = 0.0;
            }

            String oldBalanceText = jLabel38.getText()
                    .replaceAll("[^0-9.\\-]", "");

            double oldBalance = oldBalanceText.isEmpty()
                    ? 0.0
                    : Double.parseDouble(oldBalanceText);

            double balance = Math.max(
                    0.0, oldBalance + total - paid
            );

            jLabel41.setText(currency.format(paid));
            jLabel42.setText(currency.format(balance));
            jLabel37.setText(currency.format(balance));

        } catch (NumberFormatException ex) {
            jLabel41.setText("₱0.00");
            jLabel42.setText("₱0.00");
            jLabel37.setText("₱0.00");

        }
    }

    private void setupSalesTable() {

        // Create a non-editable table model
        DefaultTableModel model = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "Product", "Quantity", "Unit Price", "Total", "Actions"
                }
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTable1.setModel(model);
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable1.setFillsViewportHeight(true);

        // Remove button appearance
        javax.swing.JButton removeButton
                = new javax.swing.JButton("Remove");

        removeButton.setForeground(java.awt.Color.WHITE);
        removeButton.setBackground(new java.awt.Color(204, 51, 51));
        removeButton.setFocusPainted(false);

        jTable1.getColumnModel().getColumn(4).setCellRenderer(
                (table, value, isSelected, hasFocus, row, column) -> {
                    removeButton.setText("Remove");
                    return removeButton;
                }
        );

        // Handle clicks in the Actions column
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {

                int row = jTable1.rowAtPoint(evt.getPoint());
                int column = jTable1.columnAtPoint(evt.getPoint());

                if (row >= 0 && column == 4) {

                    int choice = JOptionPane.showConfirmDialog(
                            sales.this,
                            "Remove this item from the sales transaction?",
                            "Remove Item",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE
                    );

                    if (choice == JOptionPane.YES_OPTION) {

                        DefaultTableModel tableModel
                                = (DefaultTableModel) jTable1.getModel();

                        tableModel.removeRow(row);

                        updateTotals();
                    }
                }
            }
        });
    }

    private void loadCustomers() {

        customerIds.clear();
        customerContacts.clear();
        customerAddresses.clear();

        jComboBox3.removeAllItems();

        jComboBox3.addItem("Select Customer");

        String sql
                = "SELECT customer_id, customer_name, contact_number, address "
                + "FROM customers "
                + "WHERE archived = 0 "
                + "ORDER BY customer_name ASC";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql); ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {

                customerIds.add(
                        rs.getInt("customer_id")
                );

                customerContacts.add(
                        rs.getString("contact_number")
                );

                customerAddresses.add(
                        rs.getString("address")
                );

                jComboBox3.addItem(
                        rs.getString("customer_name")
                );
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading customers:\n"
                    + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void loadSelectedCustomer() {

        // Clear the previous customer's unsaved items.
        DefaultTableModel model
                = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        // Reset current transaction totals.
        jLabel15.setText("0");
        jLabel17.setText("₱0.00");

        // Reset all Total Gallons and Total Amount labels.
        jLabel39.setText("0");
        jLabel40.setText("₱0.00");
        jLabel8.setText("0");
        jLabel9.setText("₱0.00");

        // Reset Amount Paid and Balance Due.
        jTextField7.setText("");
        jLabel41.setText("₱0.00");
        jLabel42.setText("₱0.00");
        jLabel37.setText("₱0.00");
        jLabel38.setText("₱0.00");

        int selectedIndex = jComboBox3.getSelectedIndex();

        if (selectedIndex <= 0) {
            jTextField1.setText("");
            jTextField2.setText("");
            jTextField3.setText("");
            jLabel38.setText("₱0.00");

            updatePaymentSummary();
            updatePaymentPanel();

            return;
        }

        int customerIndex = selectedIndex - 1;

        String customerName
                = jComboBox3.getSelectedItem().toString();

        jTextField1.setText(customerName);

        jTextField2.setText(
                customerContacts.get(customerIndex) == null
                ? ""
                : customerContacts.get(customerIndex)
        );

        jTextField3.setText(
                customerAddresses.get(customerIndex) == null
                ? ""
                : customerAddresses.get(customerIndex)
        );

        // Refresh the payment summary for the new transaction.
        updatePaymentSummary();

        // Load this customer's oldest unpaid sale balance.
        loadOldestOutstandingBalance(customerIds.get(customerIndex));
    }

    private void loadOldestOutstandingBalance(int customerId) {

        String sql
                = "SELECT COALESCE(SUM(balance_due), 0) AS total_balance "
                + "FROM sales "
                + "WHERE customer_id = ? AND balance_due > 0";

        try (
                Connection con = DBConnection.getConnection(); PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setInt(1, customerId);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    jLabel38.setText(
                            String.format("₱%.2f",
                                    rs.getDouble("total_balance"))
                    );
                }
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Could not load outstanding balance:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        updatePaymentSummary();
    }

    private void formatSalesTable() {

        DefaultTableCellRenderer pesoRenderer
                = new DefaultTableCellRenderer() {

            @Override
            public void setValue(Object value) {

                if (value instanceof Number) {

                    double amount
                            = ((Number) value).doubleValue();

                    setText(String.format("₱%.2f", amount));

                } else {

                    setText(
                            value == null
                                    ? ""
                                    : value.toString()
                    );
                }
            }
        };

        pesoRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.RIGHT
        );

        jTable1.getColumnModel()
                .getColumn(2)
                .setCellRenderer(pesoRenderer);

        jTable1.getColumnModel()
                .getColumn(3)
                .setCellRenderer(pesoRenderer);

        DefaultTableCellRenderer quantityRenderer
                = new DefaultTableCellRenderer();

        quantityRenderer.setHorizontalAlignment(
                javax.swing.SwingConstants.RIGHT
        );

        jTable1.getColumnModel()
                .getColumn(1)
                .setCellRenderer(quantityRenderer);
    }

    private void addItem() {

        String sql
                = "SELECT product_id, product_name, price, stock_quantity "
                + "FROM products "
                + "WHERE archived = 0 "
                + "ORDER BY product_name";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql); ResultSet rs = pst.executeQuery()) {

            java.util.ArrayList<String> productNames
                    = new java.util.ArrayList<>();

            java.util.HashMap<String, Double> prices
                    = new java.util.HashMap<>();

            java.util.HashMap<String, Integer> stocks
                    = new java.util.HashMap<>();

            while (rs.next()) {

                String productName
                        = rs.getString("product_name");

                double price
                        = rs.getDouble("price");

                int stock
                        = rs.getInt("stock_quantity");

                productNames.add(productName);
                prices.put(productName, price);
                stocks.put(productName, stock);
            }

            if (productNames.isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "No products found in the inventory.",
                        "No Products",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            String selectedProduct
                    = (String) JOptionPane.showInputDialog(
                            this,
                            "Select Product:",
                            "Add Item",
                            JOptionPane.PLAIN_MESSAGE,
                            null,
                            productNames.toArray(),
                            productNames.get(0)
                    );

            if (selectedProduct == null) {
                return;
            }

            String quantityInput
                    = JOptionPane.showInputDialog(
                            this,
                            "Enter Quantity:",
                            "Quantity",
                            JOptionPane.PLAIN_MESSAGE
                    );

            if (quantityInput == null) {
                return;
            }

            int quantity;

            try {
                quantity = Integer.parseInt(quantityInput);
            } catch (NumberFormatException e) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please enter a valid quantity.",
                        "Invalid Quantity",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            if (quantity <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Quantity must be greater than 0.",
                        "Invalid Quantity",
                        JOptionPane.ERROR_MESSAGE
                );

                return;
            }

            int availableStock
                    = stocks.get(selectedProduct);

            if (quantity > availableStock) {

                JOptionPane.showMessageDialog(
                        this,
                        "Not enough stock.\n\n"
                        + "Available stock: " + availableStock
                        + "\nRequested: " + quantity,
                        "Insufficient Stock",
                        JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            double unitPrice
                    = prices.get(selectedProduct);

            double total
                    = unitPrice * quantity;

            DefaultTableModel model
                    = (DefaultTableModel) jTable1.getModel();

            for (int i = model.getRowCount() - 1; i >= 0; i--) {

                Object product
                        = model.getValueAt(i, 0);

                if (product == null
                        || product.toString().trim().isEmpty()) {

                    model.removeRow(i);
                }
            }

            model.addRow(new Object[]{
                selectedProduct,
                quantity,
                unitPrice,
                total,
                "Remove"
            });

            formatSalesTable();

            updateTotals();

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading products:\n"
                    + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void updateTotals() {

        DefaultTableModel model
                = (DefaultTableModel) jTable1.getModel();

        int totalGallons = 0;
        double totalAmount = 0.0;

        for (int i = 0; i < model.getRowCount(); i++) {

            Object quantityObject = model.getValueAt(i, 1);
            Object totalObject = model.getValueAt(i, 3);

            if (quantityObject != null && totalObject != null) {
                try {
                    int quantity = Integer.parseInt(
                            quantityObject.toString().trim()
                    );

                    double total = Double.parseDouble(
                            totalObject.toString()
                                    .replace("₱", "")
                                    .replace(",", "")
                                    .trim()
                    );

                    totalGallons += quantity;
                    totalAmount += total;

                } catch (NumberFormatException e) {
                    // Skip rows containing invalid values.
                }
            }
        }

        // Current transaction: total gallons
        jLabel15.setText(String.valueOf(totalGallons));
        jLabel39.setText(String.valueOf(totalGallons));
        jLabel8.setText(String.valueOf(totalGallons));

        // Current transaction: total amount
        String amountText = String.format("₱%,.2f", totalAmount);

        jLabel17.setText(amountText);
        jLabel40.setText(amountText);
        jLabel9.setText(amountText);

        // Keep balance due and payment summary updated.
        updatePaymentSummary();

    }

    private void updatePaymentPanel() {

        // New transaction starts at zero.
        // Do not load the customer's previous sales history.
        updatePaymentSummary();
    }

    private void saveSales() {

        if (jComboBox3.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Please select a customer.");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please add at least one product.");
            return;
        }

        int customerId = customerIds.get(
                jComboBox3.getSelectedIndex() - 1
        );
        String paymentMethod = jComboBox2.getSelectedItem().toString();

        double totalAmount = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            totalAmount += Double.parseDouble(model.getValueAt(i, 3).toString());
        }

        // Read the initial payment from jTextField7.
        double amountPaid;

        try {
            String paidText = jTextField7.getText()
                    .trim()
                    .replace(",", "")
                    .replace("₱", "");

            amountPaid = paidText.isEmpty()
                    ? 0.0
                    : Double.parseDouble(paidText);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid amount paid."
            );
            return;
        }

        if (amountPaid < 0) {
            JOptionPane.showMessageDialog(this,
                    "Amount paid cannot be negative.");
            return;
        }

        Connection con = null;

        try {
            con = DBConnection.getConnection();

            if (con == null) {
                JOptionPane.showMessageDialog(this,
                        "Database connection failed.");
                return;
            }

            con.setAutoCommit(false);

            java.util.List<Object[]> outstandingSales
                    = getOutstandingSales(con, customerId);

            double oldBalanceTotal = 0.0;

            for (Object[] outstanding : outstandingSales) {
                oldBalanceTotal += (double) outstanding[1];
            }

            double totalAmountDue = oldBalanceTotal + totalAmount;

            if (amountPaid > totalAmountDue) {
                throw new SQLException(
                        String.format(
                                "Amount paid cannot be greater than the total amount due of ₱%.2f.",
                                totalAmountDue));
            }

            // 1. Create one sales transaction for the customer.
            int saleId;

            String saleSQL
                    = "INSERT INTO sales "
                    + "(sale_date, customer_id, total_amount, "
                    + "payment_method, amount_paid, balance_due) "
                    + "VALUES (NOW(), ?, ?, ?, ?, ?)";

            try (PreparedStatement pst = con.prepareStatement(
                    saleSQL, java.sql.Statement.RETURN_GENERATED_KEYS)) {

                pst.setInt(1, customerId);
                pst.setDouble(2, totalAmount);
                pst.setString(3, paymentMethod);
                pst.setDouble(4, 0.0);
                pst.setDouble(5, totalAmount);

                pst.executeUpdate();

                try (ResultSet keys = pst.getGeneratedKeys()) {
                    if (!keys.next()) {
                        throw new SQLException("Could not get the sale ID.");
                    }

                    saleId = keys.getInt(1);
                }
            }

            // 2. Save each product and deduct its stock.
            String productSQL
                    = "SELECT product_id, stock_quantity, price "
                    + "FROM products "
                    + "WHERE product_name = ? AND archived = 0 FOR UPDATE";

            String stockSQL
                    = "UPDATE products "
                    + "SET stock_quantity = stock_quantity - ? "
                    + "WHERE product_id = ? AND stock_quantity >= ?";

            String itemSQL
                    = "INSERT INTO sale_items "
                    + "(sale_id, product_id, quantity, unit_price, subtotal) "
                    + "VALUES (?, ?, ?, ?, ?)";

            for (int i = 0; i < model.getRowCount(); i++) {

                String productName = model.getValueAt(i, 0).toString();
                int quantity = Integer.parseInt(model.getValueAt(i, 1).toString());
                double unitPrice = Double.parseDouble(model.getValueAt(i, 2).toString());
                double subtotal = Double.parseDouble(model.getValueAt(i, 3).toString());

                int productId;
                int currentStock;

                try (PreparedStatement pst = con.prepareStatement(productSQL)) {
                    pst.setString(1, productName);

                    try (ResultSet rs = pst.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException(
                                    "Product not found: " + productName);
                        }

                        productId = rs.getInt("product_id");
                        currentStock = rs.getInt("stock_quantity");
                    }
                }

                if (quantity <= 0) {
                    throw new SQLException(
                            "Invalid quantity for " + productName);
                }

                if (currentStock < quantity) {
                    throw new SQLException(
                            "Not enough stock for " + productName
                            + ". Available stock: " + currentStock);
                }

                try (PreparedStatement pst = con.prepareStatement(stockSQL)) {
                    pst.setInt(1, quantity);
                    pst.setInt(2, productId);
                    pst.setInt(3, quantity);

                    if (pst.executeUpdate() != 1) {
                        throw new SQLException(
                                "Could not update stock for " + productName);
                    }
                }

                try (PreparedStatement pst = con.prepareStatement(itemSQL)) {
                    pst.setInt(1, saleId);
                    pst.setInt(2, productId);
                    pst.setInt(3, quantity);
                    pst.setDouble(4, unitPrice);
                    pst.setDouble(5, subtotal);
                    pst.executeUpdate();
                }
            }

            double remainingPayment = amountPaid;

            // Pay previous unpaid sales first, oldest to newest.
            for (Object[] outstanding : outstandingSales) {
                if (remainingPayment <= 0.001) {
                    break;
                }

                int oldSaleId = (int) outstanding[0];
                double oldBalance = (double) outstanding[1];

                double paymentForOldSale
                        = Math.min(remainingPayment, oldBalance);

                if (paymentForOldSale <= 0) {
                    continue;
                }

                String updateOldSale
                        = "UPDATE sales SET "
                        + "amount_paid = amount_paid + ?, "
                        + "balance_due = balance_due - ? "
                        + "WHERE sale_id = ?";

                try (PreparedStatement pst
                        = con.prepareStatement(updateOldSale)) {
                    pst.setDouble(1, paymentForOldSale);
                    pst.setDouble(2, paymentForOldSale);
                    pst.setInt(3, oldSaleId);
                    pst.executeUpdate();
                }

                String insertOldPayment
                        = "INSERT INTO payments "
                        + "(sale_id, payment_date, amount, payment_method) "
                        + "VALUES (?, CURDATE(), ?, ?)";

                try (PreparedStatement pst
                        = con.prepareStatement(insertOldPayment)) {
                    pst.setInt(1, oldSaleId);
                    pst.setDouble(2, paymentForOldSale);
                    pst.setString(3, paymentMethod);
                    pst.executeUpdate();
                }

                remainingPayment -= paymentForOldSale;
            }

            // Apply the remaining payment to the new sale.
            double paymentForNewSale = Math.min(remainingPayment, totalAmount);
            double newSaleBalance = totalAmount - paymentForNewSale;

            String updateNewSale
                    = "UPDATE sales SET amount_paid = ?, balance_due = ? "
                    + "WHERE sale_id = ?";

            try (PreparedStatement pst = con.prepareStatement(updateNewSale)) {
                pst.setDouble(1, paymentForNewSale);
                pst.setDouble(2, newSaleBalance);
                pst.setInt(3, saleId);
                pst.executeUpdate();
            }

            if (paymentForNewSale > 0) {
                String insertNewPayment
                        = "INSERT INTO payments "
                        + "(sale_id, payment_date, amount, payment_method) "
                        + "VALUES (?, CURDATE(), ?, ?)";

                try (PreparedStatement pst
                        = con.prepareStatement(insertNewPayment)) {
                    pst.setInt(1, saleId);
                    pst.setDouble(2, paymentForNewSale);
                    pst.setString(3, paymentMethod);
                    pst.executeUpdate();
                }
            }

            double remainingBalance = newSaleBalance;
            for (Object[] outstanding : outstandingSales) {
                remainingBalance += Math.max(
                        0.0, (double) outstanding[1]
                        - Math.min((double) outstanding[1], amountPaid));
            }

            // 4. Commit all database changes.
            con.commit();

            JOptionPane.showMessageDialog(this,
                    "Sale saved successfully!\n"
                    + "Total: ₱" + String.format("%.2f", totalAmount) + "\n"
                    + "Amount Paid: ₱" + String.format("%.2f", amountPaid) + "\n"
                    + "Balance Due: ₱" + String.format("%.2f", remainingBalance));

            // Clear the sales table after successful saving.
            model.setRowCount(0);

            // Reset current transaction totals.
            jLabel15.setText("0");
            jLabel17.setText("₱0.00");

            // Reset all four additional labels.
            jLabel39.setText("0");
            jLabel40.setText("₱0.00");
            jLabel8.setText("0");
            jLabel9.setText("₱0.00");

            // Reset amount paid.
            jTextField7.setText("");

            // Reset payment summary and balance due.
            jLabel41.setText("₱0.00");
            jLabel42.setText("₱0.00");
            jLabel37.setText("₱0.00");

            // Refresh this customer's outstanding balance.
            loadOldestOutstandingBalance(customerId);

            // Refresh the payment panel.
            updatePaymentPanel();

        } catch (Exception e) {

            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException rollbackError) {
                    rollbackError.printStackTrace();
                }
            }

            JOptionPane.showMessageDialog(this,
                    "Error saving sale: " + e.getMessage());

        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void clearForm() {

        DefaultTableModel model
                = (DefaultTableModel) jTable1.getModel();

        // Check whether there is anything to clear.
        boolean hasData = model.getRowCount() > 0
                || !jTextField7.getText().trim().isEmpty();

        if (!hasData) {
            JOptionPane.showMessageDialog(
                    this,
                    "There is nothing to clear.",
                    "Clear Sales",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to clear the current transaction?",
                "Clear Sales",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {

            // Clear current transaction items.
            model.setRowCount(0);

            // Clear amount paid.
            jTextField7.setText("");

            // Reset all current transaction totals.
            updateTotals();

            // Reset payment summary and balance due.
            updatePaymentSummary();

            JOptionPane.showMessageDialog(
                    this,
                    "Current transaction cleared successfully.",
                    "Clear Sales",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    private void recordPayment() {

        if (jComboBox3.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(
                    this, "Please select a customer first.");
            return;
        }

        double paymentAmount;

        try {
            paymentAmount = Double.parseDouble(
                    jTextField6.getText().trim()
                            .replace(",", "")
                            .replace("₱", ""));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this, "Enter a valid payment amount.");
            return;
        }

        if (paymentAmount <= 0) {
            JOptionPane.showMessageDialog(
                    this, "Payment amount must be greater than zero.");
            return;
        }

        LocalDate paymentDate;

        try {
            paymentDate = LocalDate.parse(jTextField8.getText().trim());
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(
                    this, "Enter a valid date in yyyy-MM-dd format.");
            return;
        }

        int customerId = customerIds.get(
                jComboBox3.getSelectedIndex() - 1);

        String paymentMethod
                = jComboBox2.getSelectedItem().toString();

        Connection con = null;

        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            // Get all outstanding sales, oldest first.
            java.util.List<Object[]> outstandingSales
                    = getOutstandingSales(con, customerId);

            double totalOutstanding = 0.0;

            for (Object[] sale : outstandingSales) {
                totalOutstanding += (double) sale[1];
            }

            if (outstandingSales.isEmpty()) {
                throw new SQLException(
                        "This customer has no outstanding balance.");
            }

            if (paymentAmount > totalOutstanding) {
                throw new SQLException(
                        String.format(
                                "Payment exceeds the total outstanding balance of ₱%.2f.",
                                totalOutstanding));
            }

            double remainingPayment = paymentAmount;

            for (Object[] sale : outstandingSales) {

                if (remainingPayment <= 0.001) {
                    break;
                }

                int saleId = (int) sale[0];
                double balanceDue = (double) sale[1];

                double paymentForSale = Math.min(
                        remainingPayment, balanceDue);

                if (paymentForSale <= 0) {
                    continue;
                }

                // Record payment against this sale.
                String insertPaymentSQL
                        = "INSERT INTO payments "
                        + "(sale_id, payment_date, amount, payment_method) "
                        + "VALUES (?, ?, ?, ?)";

                try (PreparedStatement pst
                        = con.prepareStatement(insertPaymentSQL)) {

                    pst.setInt(1, saleId);
                    pst.setDate(2,
                            java.sql.Date.valueOf(paymentDate));
                    pst.setDouble(3, paymentForSale);
                    pst.setString(4, paymentMethod);
                    pst.executeUpdate();
                }

                // Update this sale's paid amount and remaining balance.
                String updateSaleSQL
                        = "UPDATE sales "
                        + "SET amount_paid = amount_paid + ?, "
                        + "balance_due = GREATEST(0, balance_due - ?) "
                        + "WHERE sale_id = ? AND balance_due > 0";

                try (PreparedStatement pst
                        = con.prepareStatement(updateSaleSQL)) {

                    pst.setDouble(1, paymentForSale);
                    pst.setDouble(2, paymentForSale);
                    pst.setInt(3, saleId);
                    pst.executeUpdate();
                }

                remainingPayment -= paymentForSale;
            }

            con.commit();

            double newTotalOutstanding
                    = Math.max(0.0, totalOutstanding - paymentAmount);

            // Refresh the combined balance shown in jLabel38.
            loadOldestOutstandingBalance(customerId);

            jTextField6.setText("");

            JOptionPane.showMessageDialog(
                    this,
                    String.format(
                            "Payment recorded successfully!%n"
                            + "Total Payment: ₱%.2f%n"
                            + "Remaining Outstanding Balance: ₱%.2f",
                            paymentAmount, newTotalOutstanding));

        } catch (Exception e) {

            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException rollbackError) {
                    rollbackError.printStackTrace();
                }
            }

            JOptionPane.showMessageDialog(
                    this,
                    "Could not record payment:\n" + e.getMessage(),
                    "Payment Error",
                    JOptionPane.ERROR_MESSAGE);

        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private java.util.List<Object[]> getOutstandingSales(
            Connection con, int customerId) throws SQLException {

        java.util.List<Object[]> outstandingSales
                = new java.util.ArrayList<>();

        String sql = "SELECT sale_id, balance_due FROM sales "
                + "WHERE customer_id = ? AND balance_due > 0 "
                + "ORDER BY sale_date ASC, sale_id ASC FOR UPDATE";

        try (PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, customerId);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    outstandingSales.add(new Object[]{
                        rs.getInt("sale_id"),
                        rs.getDouble("balance_due")
                    });
                }
            }
        }

        return outstandingSales;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jButton25 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton30 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel5 = new javax.swing.JPanel();
        jButton31 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton33 = new javax.swing.JButton();
        jButton34 = new javax.swing.JButton();
        jButton35 = new javax.swing.JButton();
        jButton36 = new javax.swing.JButton();
        jButton37 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton38 = new javax.swing.JButton();
        jButton39 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton7 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jTextField7 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel36 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));

        jButton15.setBackground(new java.awt.Color(0, 153, 204));
        jButton15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 255, 255));
        jButton15.setText("Dashboard");
        jButton15.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton15.addActionListener(this::jButton15ActionPerformed);

        jButton16.setBackground(new java.awt.Color(0, 153, 204));
        jButton16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton16.setForeground(new java.awt.Color(255, 255, 255));
        jButton16.setText("Inventory");
        jButton16.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton16.addActionListener(this::jButton16ActionPerformed);

        jButton17.setBackground(new java.awt.Color(0, 153, 204));
        jButton17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton17.setForeground(new java.awt.Color(255, 255, 255));
        jButton17.setText("Sales");
        jButton17.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton17.addActionListener(this::jButton17ActionPerformed);

        jButton18.setBackground(new java.awt.Color(0, 153, 204));
        jButton18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton18.setForeground(new java.awt.Color(255, 255, 255));
        jButton18.setText("Customers");
        jButton18.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton18.addActionListener(this::jButton18ActionPerformed);

        jButton19.setBackground(new java.awt.Color(0, 153, 204));
        jButton19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 255, 255));
        jButton19.setText("Reports");
        jButton19.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));

        jButton20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton20.setForeground(new java.awt.Color(51, 102, 255));
        jButton20.setText("Log Out");
        jButton20.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton20.addActionListener(this::jButton20ActionPerformed);

        jButton21.setBackground(new java.awt.Color(0, 153, 204));
        jButton21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 255, 255));
        jButton21.setText("Staff Management");
        jButton21.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton21.addActionListener(this::jButton21ActionPerformed);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JMB no bg.png"))); // NOI18N

        jButton25.setBackground(new java.awt.Color(0, 153, 204));
        jButton25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton25.setForeground(new java.awt.Color(255, 255, 255));
        jButton25.setText("Statement of Account");
        jButton25.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton25.addActionListener(this::jButton25ActionPerformed);

        jPanel4.setBackground(new java.awt.Color(0, 102, 153));

        jButton22.setBackground(new java.awt.Color(0, 153, 204));
        jButton22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton22.setForeground(new java.awt.Color(255, 255, 255));
        jButton22.setText("Dashboard");
        jButton22.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton22.addActionListener(this::jButton22ActionPerformed);

        jButton23.setBackground(new java.awt.Color(0, 153, 204));
        jButton23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton23.setForeground(new java.awt.Color(255, 255, 255));
        jButton23.setText("Inventory");
        jButton23.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton23.addActionListener(this::jButton23ActionPerformed);

        jButton24.setBackground(new java.awt.Color(0, 153, 204));
        jButton24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton24.setForeground(new java.awt.Color(255, 255, 255));
        jButton24.setText("Sales");
        jButton24.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton24.addActionListener(this::jButton24ActionPerformed);

        jButton26.setBackground(new java.awt.Color(0, 153, 204));
        jButton26.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton26.setForeground(new java.awt.Color(255, 255, 255));
        jButton26.setText("Customers");
        jButton26.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton26.addActionListener(this::jButton26ActionPerformed);

        jButton27.setBackground(new java.awt.Color(0, 153, 204));
        jButton27.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton27.setForeground(new java.awt.Color(255, 255, 255));
        jButton27.setText("Reports");
        jButton27.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));

        jButton28.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton28.setForeground(new java.awt.Color(51, 102, 255));
        jButton28.setText("Log Out");
        jButton28.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton28.addActionListener(this::jButton28ActionPerformed);

        jButton29.setBackground(new java.awt.Color(0, 153, 204));
        jButton29.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton29.setForeground(new java.awt.Color(255, 255, 255));
        jButton29.setText("Staff Management");
        jButton29.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton29.addActionListener(this::jButton29ActionPerformed);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JMB no bg.png"))); // NOI18N

        jButton30.setBackground(new java.awt.Color(0, 153, 204));
        jButton30.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton30.setForeground(new java.awt.Color(255, 255, 255));
        jButton30.setText("Statement of Account");
        jButton30.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton30.addActionListener(this::jButton30ActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGap(39, 39, 39)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addComponent(jLabel4))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(30, 30, 30)
                .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton26, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton27, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton29, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton30, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84)
                .addComponent(jButton28, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(39, 39, 39)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addComponent(jLabel3))))
                .addContainerGap(29, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(30, 30, 30)
                .addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton25, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84)
                .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel3Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel5.setBackground(new java.awt.Color(0, 102, 153));

        jButton31.setBackground(new java.awt.Color(0, 153, 204));
        jButton31.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton31.setForeground(new java.awt.Color(255, 255, 255));
        jButton31.setText("Dashboard");
        jButton31.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton31.addActionListener(this::jButton31ActionPerformed);

        jButton32.setBackground(new java.awt.Color(0, 153, 204));
        jButton32.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton32.setForeground(new java.awt.Color(255, 255, 255));
        jButton32.setText("Inventory");
        jButton32.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton32.addActionListener(this::jButton32ActionPerformed);

        jButton33.setBackground(new java.awt.Color(0, 153, 204));
        jButton33.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton33.setForeground(new java.awt.Color(255, 255, 255));
        jButton33.setText("Sales");
        jButton33.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton33.addActionListener(this::jButton33ActionPerformed);

        jButton34.setBackground(new java.awt.Color(0, 153, 204));
        jButton34.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton34.setForeground(new java.awt.Color(255, 255, 255));
        jButton34.setText("Customers");
        jButton34.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton34.addActionListener(this::jButton34ActionPerformed);

        jButton35.setBackground(new java.awt.Color(0, 153, 204));
        jButton35.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton35.setForeground(new java.awt.Color(255, 255, 255));
        jButton35.setText("Reports");
        jButton35.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton35.addActionListener(this::jButton35ActionPerformed);

        jButton36.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton36.setForeground(new java.awt.Color(51, 102, 255));
        jButton36.setText("Log Out");
        jButton36.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton36.addActionListener(this::jButton36ActionPerformed);

        jButton37.setBackground(new java.awt.Color(0, 153, 204));
        jButton37.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton37.setForeground(new java.awt.Color(255, 255, 255));
        jButton37.setText("Staff Management");
        jButton37.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton37.addActionListener(this::jButton37ActionPerformed);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JMB no bg.png"))); // NOI18N

        jButton38.setBackground(new java.awt.Color(0, 153, 204));
        jButton38.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton38.setForeground(new java.awt.Color(255, 255, 255));
        jButton38.setText("Statement of Account");
        jButton38.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton38.addActionListener(this::jButton38ActionPerformed);

        jButton39.setBackground(new java.awt.Color(0, 153, 204));
        jButton39.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton39.setForeground(new java.awt.Color(255, 255, 255));
        jButton39.setText("Products");
        jButton39.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton39.addActionListener(this::jButton39ActionPerformed);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGap(39, 39, 39)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton38, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addComponent(jLabel5))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(30, 30, 30)
                .addComponent(jButton31, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton32, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton39, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton34, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton33, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton35, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton37, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton38, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jButton36, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(479, Short.MAX_VALUE))
        );

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel6.setFont(new java.awt.Font("Segoe UI Variable", 1, 28)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 204));
        jLabel6.setText("SALES");

        jLabel7.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 102, 204));
        jLabel7.setText("Record and Manage Customer Sales Transaction");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        jLabel1.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("Sales Transactions");

        jLabel2.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setText("Customer");

        jLabel11.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 153, 255));
        jLabel11.setText("Date From");

        jLabel12.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 153, 255));
        jLabel12.setText("Payment Method");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cash on Delivery", "Gcash" }));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel18.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(51, 153, 255));
        jLabel18.setText("Date To");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(jLabel11)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel10))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(89, 89, 89)
                                .addComponent(jLabel12)))))
                .addGap(122, 122, 122))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField4)
                            .addComponent(jTextField5)
                            .addComponent(jComboBox2))
                        .addGap(181, 181, 181))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));
        jPanel6.setForeground(new java.awt.Color(0, 102, 204));

        jLabel13.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 102, 204));
        jLabel13.setText("Product and Services");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Product", "Quantity", "Unit Price", "Total", "Actions"
            }
        ));
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setHeaderValue("Product");
            jTable1.getColumnModel().getColumn(1).setHeaderValue("Quantity");
            jTable1.getColumnModel().getColumn(2).setHeaderValue("Unit Price");
            jTable1.getColumnModel().getColumn(3).setHeaderValue("Total");
            jTable1.getColumnModel().getColumn(4).setHeaderValue("Actions");
        }

        jButton7.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        jButton7.setForeground(new java.awt.Color(0, 51, 204));
        jButton7.setText("Add Item");
        jButton7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 204), 3, true));
        jButton7.addActionListener(this::jButton7ActionPerformed);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 593, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton1.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 51, 255));
        jButton1.setText("Add Item");
        jButton1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        jLabel15.setText("111111");
        jLabel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jLabel16.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 153, 204));
        jLabel16.setText("Total Amount:");

        jLabel17.setText("11111");
        jLabel17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        jButton2.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 102, 204));
        jButton2.setText("Save Sales");
        jButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));

        jButton3.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 102, 204));
        jButton3.setText("Clear");
        jButton3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 204), 1, true));

        jLabel20.setFont(new java.awt.Font("Segoe UI Variable", 1, 20)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 102, 204));
        jLabel20.setText("Customer Information");

        jLabel21.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(51, 153, 255));
        jLabel21.setText("Contact Number");

        jLabel22.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(51, 153, 255));
        jLabel22.setText("Name");

        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        jLabel23.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(51, 153, 255));
        jLabel23.setText("Address");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel22)
                            .addComponent(jLabel21))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 239, Short.MAX_VALUE)
                            .addComponent(jTextField2))
                        .addGap(50, 50, 50)
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel22)
                        .addComponent(jLabel23)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(204, 204, 255));
        jPanel7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 0, 204), 2, true));

        jLabel24.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(51, 153, 255));
        jLabel24.setText("Total Galloons");

        jLabel39.setText("jLabel39");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(jLabel39))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel24)))
                .addContainerGap(117, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel24)
                .addGap(20, 20, 20)
                .addComponent(jLabel39)
                .addGap(0, 36, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(204, 204, 255));
        jPanel9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 0, 204), 2, true));

        jLabel25.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(51, 153, 255));
        jLabel25.setText("Total Amount");

        jLabel40.setText("jLabel40");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel25))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(jLabel40)))
                .addContainerGap(98, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel25)
                .addGap(22, 22, 22)
                .addComponent(jLabel40)
                .addGap(0, 34, Short.MAX_VALUE))
        );

        jPanel10.setBackground(new java.awt.Color(204, 204, 255));
        jPanel10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 0, 204), 2, true));

        jLabel26.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(51, 153, 255));
        jLabel26.setText("Amount Paid");

        jLabel41.setText("jLabel41");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel26))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(jLabel41)))
                .addContainerGap(93, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel26)
                .addGap(18, 18, 18)
                .addComponent(jLabel41)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        jPanel11.setBackground(new java.awt.Color(204, 204, 255));
        jPanel11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 0, 204), 2, true));

        jLabel27.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(51, 153, 255));
        jLabel27.setText("Balance Due");

        jLabel42.setText("jLabel42");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel27))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(jLabel42)))
                .addContainerGap(91, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel27)
                .addGap(18, 18, 18)
                .addComponent(jLabel42)
                .addGap(0, 38, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 102, 204), 2, true));
        jPanel12.setPreferredSize(new java.awt.Dimension(328, 332));

        jLabel19.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 102, 204));
        jLabel19.setText("Sales");

        jLabel28.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(51, 153, 255));
        jLabel28.setText("Total Galloons");

        jLabel29.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(51, 153, 255));
        jLabel29.setText("Total Amount:");

        jLabel30.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(51, 153, 255));
        jLabel30.setText("Amount Paid:");

        jLabel31.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(51, 153, 255));
        jLabel31.setText("Balance Due:");

        jButton5.setForeground(new java.awt.Color(51, 0, 204));
        jButton5.setText("Save Sales");
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jButton6.setForeground(new java.awt.Color(0, 0, 204));
        jButton6.setText("Clear");
        jButton6.addActionListener(this::jButton6ActionPerformed);

        jTextField7.setText("jTextField7");

        jLabel8.setText("jLabel8");

        jLabel9.setText("jLabel9");

        jLabel37.setText("jLabel37");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel28)
                            .addComponent(jLabel29))
                        .addGap(48, 48, 48)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel8)))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jButton5)
                        .addGap(51, 51, 51)
                        .addComponent(jButton6))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel31)
                        .addGap(57, 57, 57)
                        .addComponent(jLabel37))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel19)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel28)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jLabel37))
                .addGap(41, 41, 41)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        jPanel13.setBackground(new java.awt.Color(204, 204, 255));
        jPanel13.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 204), 3, true));

        jLabel32.setFont(new java.awt.Font("Segoe UI Variable", 1, 22)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(0, 102, 204));
        jLabel32.setText("Pay Balance");

        jLabel33.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(51, 153, 255));
        jLabel33.setText("Outstanding Balance");

        jLabel34.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(51, 153, 255));
        jLabel34.setText("Payment Amount");

        jTextField6.setText("jTextField6");

        jLabel35.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(51, 153, 255));
        jLabel35.setText("Payment Method");

        jRadioButton1.setText("Cash on Delivery");

        jRadioButton2.setText("Gcash");

        jLabel36.setFont(new java.awt.Font("Segoe UI Variable", 1, 16)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(51, 153, 255));
        jLabel36.setText("Payment Date");

        jButton8.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jButton8.setForeground(new java.awt.Color(0, 153, 204));
        jButton8.setText("Record Payment");
        jButton8.addActionListener(this::jButton8ActionPerformed);

        jLabel38.setText("jLabel38");

        jTextField8.setText("jTextField8");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel33)
                            .addComponent(jLabel34)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(97, 97, 97)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel13Layout.createSequentialGroup()
                                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jRadioButton1)
                                    .addComponent(jRadioButton2))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(87, 87, 87)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel32)
                .addGap(28, 28, 28)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel35)
                    .addComponent(jLabel33)
                    .addComponent(jLabel36))
                .addGap(18, 18, 18)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jRadioButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel34)
                            .addComponent(jRadioButton2)))
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField6, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(851, 851, 851)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(412, 412, 412)
                        .addComponent(jLabel16)
                        .addGap(127, 127, 127)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 21, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(404, 404, 404))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE))
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 659, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(641, 641, 641))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1028, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 61, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        AdminDashboard AdminDashboard = new AdminDashboard();

        AdminDashboard.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        Inventory Inventory = new Inventory();

        Inventory.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        customers customers = new customers();

        customers.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed

        AdminLogin AdminLoginForm = new AdminLogin();

        AdminLoginForm.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        staffmanagement staffmanagement = new staffmanagement();

        staffmanagement.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        AdminDashboard AdminDashboard = new AdminDashboard();

        AdminDashboard.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        Inventory Inventory = new Inventory();

        Inventory.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        customers customers = new customers();

        customers.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed

        AdminLogin AdminLoginForm = new AdminLogin();

        AdminLoginForm.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        staffmanagement staffmanagement = new staffmanagement();

        staffmanagement.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        AdminDashboard AdminDashboard = new AdminDashboard();

        AdminDashboard.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        Inventory Inventory = new Inventory();

        Inventory.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jButton33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton33ActionPerformed
        sales sales = new sales();

        sales.setVisible(true);

        this.dispose();    }//GEN-LAST:event_jButton33ActionPerformed

    private void jButton34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton34ActionPerformed
        customers customers = new customers();

        customers.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton34ActionPerformed

    private void jButton36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton36ActionPerformed
        AdminLogin AdminLoginForm = new AdminLogin();

        AdminLoginForm.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton36ActionPerformed

    private void jButton37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton37ActionPerformed
        staffmanagement staffmanagement = new staffmanagement();

        staffmanagement.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton37ActionPerformed

    private void jButton38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton38ActionPerformed
        AdminSOA AdminSOA = new AdminSOA();

        AdminSOA.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton38ActionPerformed

    private void jButton35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton35ActionPerformed
        reports reports = new reports();

        reports.setVisible(true);

        this.dispose();       }//GEN-LAST:event_jButton35ActionPerformed

    private void jButton39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton39ActionPerformed
        Products products = new Products();

        products.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton39ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        saveSales();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        clearForm();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        addItem();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        clearForm();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        recordPayment();
    }//GEN-LAST:event_jButton8ActionPerformed

        /**
         * @param args the command line arguments
         */
        public static void main(String args[]) {
            /* Set the Nimbus look and feel */
            //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
             */
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
                logger.log(java.util.logging.Level.SEVERE, null, ex);
            }
            //</editor-fold>

            /* Create and display the form */
            java.awt.EventQueue.invokeLater(() -> new sales().setVisible(true));
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton33;
    private javax.swing.JButton jButton34;
    private javax.swing.JButton jButton35;
    private javax.swing.JButton jButton36;
    private javax.swing.JButton jButton37;
    private javax.swing.JButton jButton38;
    private javax.swing.JButton jButton39;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    // End of variables declaration//GEN-END:variables
}
