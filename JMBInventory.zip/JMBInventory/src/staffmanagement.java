/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 *
 * @author HP
 */
public class staffmanagement extends javax.swing.JFrame {

    private char passwordEchoChar;
    private char confirmPasswordEchoChar;
    private int selectedRoleId = -1;
    private String selectedOldPassword = "";
    private boolean editMode = false;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(staffmanagement.class.getName());

    public staffmanagement() {
        initComponents();

        // Contact Number: digits only, maximum 11 digits.
        ((AbstractDocument) jTextField1.getDocument())
                .setDocumentFilter(new DocumentFilter() {

                    @Override
                    public void insertString(
                            FilterBypass fb,
                            int offset,
                            String text,
                            AttributeSet attr
                    ) throws BadLocationException {

                        if (text == null || !text.matches("[0-9]*")) {
                            return;
                        }

                        if (fb.getDocument().getLength() + text.length() <= 11) {
                            super.insertString(fb, offset, text, attr);
                        }
                    }

                    @Override
                    public void replace(
                            FilterBypass fb,
                            int offset,
                            int length,
                            String text,
                            AttributeSet attrs
                    ) throws BadLocationException {

                        if (text == null) {
                            text = "";
                        }

                        if (!text.matches("[0-9]*")) {
                            return;
                        }

                        int newLength = fb.getDocument().getLength()
                                - length + text.length();

                        if (newLength <= 11) {
                            super.replace(fb, offset, length, text, attrs);
                        }
                    }
                });

        DateTimeFormatter formatter
                = DateTimeFormatter.ofPattern("MMMM dd, yyyy");

        lblDate2.setText(LocalDate.now().format(formatter));

        // Remember the original password masking characters.
        passwordEchoChar = jPasswordField1.getEchoChar();
        confirmPasswordEchoChar = jPasswordField2.getEchoChar();

        // Table columns:
        // The first column is the actual database account ID.
        // We will hide it but keep it for editing and deleting.
        DefaultTableModel tableModel = new DefaultTableModel(
                new Object[]{
                    "Account ID",
                    "ID",
                    "Username",
                    "Contact Number",
                    "Role",
                    "Status"
                },
                0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        jTable1.setModel(tableModel);

        // Hide the actual database ID column.
        // It remains in the model for database operations.
        jTable1.removeColumn(
                jTable1.getColumnModel().getColumn(0)
        );

        // Role dropdown: number and role name.
        jComboBox1.setModel(
                new javax.swing.DefaultComboBoxModel<>(
                        new String[]{
                            "1 - ADMIN",
                            "2 - STAFF"
                        }
                )
        );

// Display only the selected role number in jTextField2.
        jTextField2.setEditable(false);
        jComboBox1.setSelectedItem("1 - ADMIN");
        jTextField2.setText("1");

// Right-click an account row to change its status.
        setupStatusMenu();

// Color ACTIVE and INACTIVE status text.
        setupStatusColors();

        loadAccounts();
    }

    private void loadAccounts() {

        DefaultTableModel model
                = (DefaultTableModel) jTable1.getModel();

        model.setRowCount(0);

        String sql
                = "SELECT role_id, username, contact_number, role, status "
                + "FROM users ORDER BY role_id";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql); ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {

                String role = rs.getString("role");

                // Visible ID: 1 for ADMIN, 2 for STAFF.
                int displayRoleId
                        = "admin".equalsIgnoreCase(role) ? 1 : 2;

                String contactNumber
                        = rs.getString("contact_number");

                String status = rs.getString("status");

                if (contactNumber == null) {
                    contactNumber = "";
                }

                if (status == null || status.trim().isEmpty()) {
                    status = "Active";
                }

                model.addRow(new Object[]{
                    rs.getInt("role_id"), // Hidden actual account ID
                    displayRoleId, // Visible ID: 1 or 2
                    rs.getString("username"),
                    contactNumber,
                    role.toUpperCase(),
                    status.toUpperCase()
                });
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error loading accounts:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void setupStatusMenu() {

        javax.swing.JPopupMenu statusMenu
                = new javax.swing.JPopupMenu();

        javax.swing.JMenuItem setActive
                = new javax.swing.JMenuItem("Set Active");

        javax.swing.JMenuItem setInactive
                = new javax.swing.JMenuItem("Set Inactive");

        setActive.addActionListener(
                e -> updateSelectedAccountStatus("Active")
        );

        setInactive.addActionListener(
                e -> updateSelectedAccountStatus("Inactive")
        );

        statusMenu.add(setActive);
        statusMenu.add(setInactive);

        jTable1.setComponentPopupMenu(statusMenu);

        jTable1.setToolTipText(
                "Right-click an account row to change its status."
        );

        jTable1.addMouseListener(
                new java.awt.event.MouseAdapter() {

            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {

                if (javax.swing.SwingUtilities.isRightMouseButton(e)) {

                    int row = jTable1.rowAtPoint(e.getPoint());

                    if (row >= 0) {
                        jTable1.setRowSelectionInterval(row, row);
                    }
                }
            }
        });
    }

    private void updateSelectedAccountStatus(String status) {

        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an account first."
            );
            return;
        }

        int modelRow = jTable1.convertRowIndexToModel(selectedRow);

        int accountId = Integer.parseInt(
                jTable1.getModel().getValueAt(modelRow, 0).toString()
        );

        String username
                = jTable1.getModel().getValueAt(modelRow, 2).toString();

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Set account '" + username + "' to "
                + status.toUpperCase() + "?",
                "Confirm Status Change",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "UPDATE users SET status = ? WHERE role_id = ?";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, status);
            pst.setInt(2, accountId);

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Account status changed to "
                        + status.toUpperCase() + "."
                );

                loadAccounts();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Account was not found."
                );
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error updating account status:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void setupStatusColors() {

        int statusColumn
                = jTable1.getColumnModel().getColumnIndex("Status");

        jTable1.getColumnModel()
                .getColumn(statusColumn)
                .setCellRenderer(new DefaultTableCellRenderer() {

                    @Override
                    public Component getTableCellRendererComponent(
                            JTable table,
                            Object value,
                            boolean isSelected,
                            boolean hasFocus,
                            int row,
                            int column) {

                        Component component
                                = super.getTableCellRendererComponent(
                                        table,
                                        value,
                                        isSelected,
                                        hasFocus,
                                        row,
                                        column
                                );

                        String status = value == null
                                ? ""
                                : value.toString().trim();

                        if (status.equalsIgnoreCase("ACTIVE")) {

                            component.setForeground(new Color(0, 150, 0));

                        } else if (status.equalsIgnoreCase("INACTIVE")) {

                            component.setForeground(Color.RED);

                        } else {

                            component.setForeground(table.getForeground());
                        }

                        component.setFont(
                                component.getFont().deriveFont(
                                        java.awt.Font.BOLD
                                )
                        );

                        return component;
                    }
                });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblDate2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();
        jButton8 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jCheckBox1 = new javax.swing.JCheckBox();
        jLabel8 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 153));

        jButton1.setBackground(new java.awt.Color(0, 153, 204));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Dashboard");
        jButton1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setBackground(new java.awt.Color(0, 153, 204));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Inventory");
        jButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setBackground(new java.awt.Color(0, 153, 204));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Sales");
        jButton3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton4.setBackground(new java.awt.Color(0, 153, 204));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Customers");
        jButton4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton5.setBackground(new java.awt.Color(0, 153, 204));
        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Reports");
        jButton5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(51, 102, 255));
        jButton6.setText("Log Out");
        jButton6.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        jButton6.addActionListener(this::jButton6ActionPerformed);

        jButton7.setBackground(new java.awt.Color(0, 153, 204));
        jButton7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Staff Management");
        jButton7.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton7.addActionListener(this::jButton7ActionPerformed);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/JMB no bg.png"))); // NOI18N

        jButton11.setBackground(new java.awt.Color(0, 153, 204));
        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("Statement of Account");
        jButton11.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton11.addActionListener(this::jButton11ActionPerformed);

        jButton12.setBackground(new java.awt.Color(0, 153, 204));
        jButton12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("Products");
        jButton12.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        jButton12.addActionListener(this::jButton12ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(39, 39, 39)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addComponent(jLabel1))))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI Variable", 1, 28)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("STAFF & ACCOUNT MANAGEMENT");

        jLabel3.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 204));
        jLabel3.setText("Manage staff accounts and information.");

        lblDate2.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        lblDate2.setForeground(new java.awt.Color(0, 102, 204));
        lblDate2.setText("Date");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "ID", "Username", "Role"
            }
        ));
        jTable1.setSelectionBackground(new java.awt.Color(102, 102, 102));
        jScrollPane1.setViewportView(jTable1);

        jPanel3.setBackground(new java.awt.Color(0, 153, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setFont(new java.awt.Font("Segoe UI Historic", 1, 22)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Create An Account");

        jTextField1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        jPasswordField1.setToolTipText("");

        jButton8.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(0, 102, 204));
        jButton8.setText("Create Account");
        jButton8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        jButton8.addActionListener(this::jButton8ActionPerformed);

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Username");

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Password");

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Confirm Password");

        jTextField2.addActionListener(this::jTextField2ActionPerformed);

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 15)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Role");

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Contact Number");

        jTextField3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 1, true));
        jTextField3.addActionListener(this::jTextField3ActionPerformed);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        jCheckBox1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jCheckBox1.setForeground(new java.awt.Color(255, 255, 255));
        jCheckBox1.setText("Show Password");
        jCheckBox1.addActionListener(this::jCheckBox1ActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel4))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(30, 30, 30)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel10)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6)))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(42, 42, 42)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jCheckBox1))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(43, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(108, 108, 108))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(26, 26, 26)
                .addComponent(jLabel5)
                .addGap(12, 12, 12)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jCheckBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)))
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );

        jPasswordField1.getAccessibleContext().setAccessibleName("");
        jPasswordField2.getAccessibleContext().setAccessibleParent(lblDate2);

        jLabel8.setFont(new java.awt.Font("Segoe UI Variable", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 204));
        jLabel8.setText("STAFF LIST");

        jButton9.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        jButton9.setForeground(new java.awt.Color(51, 102, 255));
        jButton9.setText("EDIT");
        jButton9.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 204), 2, true));
        jButton9.addActionListener(this::jButton9ActionPerformed);

        jButton10.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        jButton10.setForeground(new java.awt.Color(51, 102, 255));
        jButton10.setText("DELETE");
        jButton10.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 153, 204), 2, true));
        jButton10.addActionListener(this::jButton10ActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(jLabel3))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 661, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(120, 120, 120)
                                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(130, 130, 130)
                                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(69, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblDate2)
                        .addGap(58, 58, 58))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblDate2)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(0, 0, 0)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(78, 78, 78))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(28, 28, 28))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        AdminDashboard AdminDashboard = new AdminDashboard();

        AdminDashboard.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        AdminLogin AdminLoginForm = new AdminLogin();

        AdminLoginForm.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        sales sales = new sales();

        sales.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        customers customers = new customers();

        customers.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Inventory Inventory = new Inventory();

        Inventory.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        staffmanagement staffmanagement = new staffmanagement();

        staffmanagement.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        reports reports = new reports();

        reports.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // Your form's actual field mapping:
        String username = jTextField3.getText().trim();
        String contactNumber = jTextField1.getText().trim();

        String password
                = new String(jPasswordField1.getPassword());

        String confirmPassword
                = new String(jPasswordField2.getPassword());

        String selectedRole
                = String.valueOf(jComboBox1.getSelectedItem());

        String role;
        String roleNumber;

        if (selectedRole.startsWith("1")) {

            roleNumber = "1";
            role = "admin";

        } else if (selectedRole.startsWith("2")) {

            roleNumber = "2";
            role = "staff";

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a valid role."
            );
            return;
        }

        boolean editing = editMode;

        if (username.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username is required.");
            jTextField3.requestFocus();
            return;
        }

        if (contactNumber.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Contact number is required.");
            jTextField1.requestFocus();
            return;
        }

        if (!contactNumber.matches("[0-9]{11}")) {
            JOptionPane.showMessageDialog(
                    this,
                    "Contact number must contain exactly 11 digits.",
                    "Invalid Contact Number",
                    JOptionPane.WARNING_MESSAGE
            );

            jTextField1.requestFocus();
            return;
        }

        if (!editing && password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Password is required.");
            jPasswordField1.requestFocus();
            return;
        }

        if (!password.isEmpty() && confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please confirm the password."
            );
            jPasswordField2.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            // Allow both password fields to remain blank during editing.
            if (!editing || !password.isEmpty() || !confirmPassword.isEmpty()) {
                JOptionPane.showMessageDialog(
                        this,
                        "Passwords do not match."
                );

                jPasswordField2.setText("");
                jPasswordField2.requestFocus();
                return;
            }
        }

        String checkSql;

        if (editing) {
            checkSql
                    = "SELECT role_id FROM users "
                    + "WHERE username = ? AND role_id <> ?";
        } else {
            checkSql
                    = "SELECT role_id FROM users WHERE username = ?";
        }

        try (Connection conn = DBConnection.getConnection()) {

            // Check whether the username already exists.
            try (PreparedStatement checkPst
                    = conn.prepareStatement(checkSql)) {

                checkPst.setString(1, username);

                if (editing) {
                    checkPst.setInt(2, selectedRoleId);
                }

                try (ResultSet rs = checkPst.executeQuery()) {

                    if (rs.next()) {
                        JOptionPane.showMessageDialog(
                                this,
                                "Username already exists."
                        );
                        jTextField3.requestFocus();
                        return;
                    }
                }
            }

            int rowsAffected;

            if (editing) {

                String passwordToSave = password.isEmpty()
                        ? selectedOldPassword
                        : password;

                String updateSql
                        = "UPDATE users SET username = ?, "
                        + "contact_number = ?, password = ?, role = ? "
                        + "WHERE role_id = ?";

                try (PreparedStatement pst
                        = conn.prepareStatement(updateSql)) {

                    pst.setString(1, username);
                    pst.setString(2, contactNumber);
                    pst.setString(3, passwordToSave);
                    pst.setString(4, role);
                    pst.setInt(5, selectedRoleId);

                    rowsAffected = pst.executeUpdate();
                }

            } else {

                String insertSql
                        = "INSERT INTO users "
                        + "(username, contact_number, password, role, status) "
                        + "VALUES (?, ?, ?, ?, 'Active')";

                try (PreparedStatement pst
                        = conn.prepareStatement(insertSql)) {

                    pst.setString(1, username);
                    pst.setString(2, contactNumber);
                    pst.setString(3, password);
                    pst.setString(4, role);

                    rowsAffected = pst.executeUpdate();
                }
            }

            if (rowsAffected > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        editing
                                ? "Account updated successfully!"
                                : "Account created successfully!"
                );

                selectedRoleId = -1;
                selectedOldPassword = "";
                editMode = false;

// 🟢 Enable password fields again.
                jPasswordField1.setEditable(true);
                jPasswordField2.setEditable(true);

// 🟢 Restore the original button text.
                jButton8.setText("Create Account");

                clearFields();
                loadAccounts();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "No account changes were made."
                );
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error saving account:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an account to delete."
            );
            return;
        }

        // Convert to the model row, in case the table is sorted.
        int modelRow = jTable1.convertRowIndexToModel(selectedRow);

        // Column 0 in the model is the hidden, real database ID.
        int accountId = Integer.parseInt(
                jTable1.getModel().getValueAt(modelRow, 0).toString()
        );

        String username
                = jTable1.getModel().getValueAt(modelRow, 2).toString();

        String role
                = jTable1.getModel().getValueAt(modelRow, 4).toString();

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this account?\n\n"
                + "Username: " + username + "\n"
                + "Role: " + role,
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM users WHERE role_id = ?";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, accountId);

            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Account deleted successfully!"
                );

                selectedRoleId = -1;
                selectedOldPassword = "";
                editMode = false;

                clearFields();
                loadAccounts();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Account was not found."
                );
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error deleting account:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select an account to edit."
            );
            return;
        }

        int modelRow = jTable1.convertRowIndexToModel(selectedRow);

        selectedRoleId = Integer.parseInt(
                jTable1.getModel().getValueAt(modelRow, 0).toString()
        );

        String sql = "SELECT username, contact_number, password, role "
                + "FROM users WHERE role_id = ?";

        try (
                Connection conn = DBConnection.getConnection(); PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, selectedRoleId);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {

                    selectedOldPassword = rs.getString("password");

                    jTextField3.setText(rs.getString("username"));
                    jTextField1.setText(rs.getString("contact_number"));

                    String role = rs.getString("role");

                    if ("admin".equalsIgnoreCase(role)) {
                        jComboBox1.setSelectedItem("1 - ADMIN");
                        jTextField2.setText("1");
                    } else {
                        jComboBox1.setSelectedItem("2 - STAFF");
                        jTextField2.setText("2");
                    }

                    // 🟢 Disable password editing.
                    jPasswordField1.setText("");
                    jPasswordField2.setText("");
                    jPasswordField1.setEditable(false);
                    jPasswordField2.setEditable(false);
                    jCheckBox1.setEnabled(false);

                    // 🟢 Change Create Account button to Save.
                    editMode = true;
                    jButton8.setText("Save");
                    jLabel4.setText("Edit Account");

                    JOptionPane.showMessageDialog(
                            this,
                            "Account loaded for editing.\n\n"
                            + "Password and Confirm Password are disabled.\n"
                            + "You can edit the username, contact number, "
                            + "and role.\n"
                            + "Click Save to apply changes."
                    );

                } else {
                    JOptionPane.showMessageDialog(
                            this,
                            "Account was not found."
                    );

                    selectedRoleId = -1;
                    selectedOldPassword = "";
                    editMode = false;

                    clearFields();
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error loading account:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        AdminSOA AdminSOA = new AdminSOA();

        AdminSOA.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        Products products = new Products();

        products.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        Object selected = jComboBox1.getSelectedItem();

        if (selected == null) {
            return;
        }

        String selectedRole = selected.toString();

        if (selectedRole.startsWith("1")) {
            jTextField2.setText("1");
        } else if (selectedRole.startsWith("2")) {
            jTextField2.setText("2");
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        if (jCheckBox1.isSelected()) {

            // Show passwords.
            jPasswordField1.setEchoChar((char) 0);
            jPasswordField2.setEchoChar((char) 0);

        } else {

            // Restore the original password masking characters.
            jPasswordField1.setEchoChar(passwordEchoChar);
            jPasswordField2.setEchoChar(confirmPasswordEchoChar);
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed
    private void clearFields() {
        jTextField3.setText("");
        jTextField1.setText("");

        jPasswordField1.setText("");
        jPasswordField2.setText("");

        // 🟢 Enable passwords for creating a new account.
        jPasswordField1.setEditable(true);
        jPasswordField2.setEditable(true);

        // Reset role to ADMIN.
        jComboBox1.setSelectedItem("1 - ADMIN");
        jTextField2.setText("1");

        // Restore password masking.
        jCheckBox1.setSelected(false);
        jCheckBox1.setEnabled(true);
        jPasswordField1.setEchoChar(passwordEchoChar);
        jPasswordField2.setEchoChar(confirmPasswordEchoChar);

        // Reset edit mode and button text.
        editMode = false;
        jButton8.setText("Create Account");

        jLabel4.setText("Create An Account");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new staffmanagement().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblDate2;
    // End of variables declaration//GEN-END:variables
}
